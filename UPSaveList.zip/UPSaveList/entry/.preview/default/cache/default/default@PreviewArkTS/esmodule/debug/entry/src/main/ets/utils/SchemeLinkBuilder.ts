import type common from "@ohos:app.ability.common";
import type Want from "@ohos:app.ability.Want";
/**
 * B 站 scheme 链接格式：
 *   bilibili://space/{mid}       — 打开 UP 主空间
 *   bilibili://video/{bvid}      — 打开视频页
 *   bilibili://user/{mid}        — 打开用户主页（备选）
 *
 * 抖音 scheme 链接格式：
 *   snssdk1128://user/{sec_uid}  — 打开用户主页
 *   aweme://user/{sec_uid}       — 备选 scheme
 *
 * 快手 scheme 链接格式：
 *   kuaishou://profile/{user_id} — 打开用户主页
 *   kwai://profile/{user_id}     — 备选 scheme
 */
export function getSchemeLink(platform: string, uid: string): string {
    switch (platform) {
        case 'bilibili':
            return `bilibili://space/${uid}`;
        case 'douyin':
            return `snssdk1128://user/${uid}`;
        case 'kuaishou':
            return `kwai://profile/${uid}`;
        default:
            return '';
    }
}
/**
 * 获取备选 scheme 链接（当主 scheme 跳转失败时尝试）
 */
export function getAlternativeSchemeLink(platform: string, uid: string): string {
    switch (platform) {
        case 'bilibili':
            return `bilibili://user/${uid}`;
        case 'douyin':
            return `aweme://user/${uid}`;
        case 'kuaishou':
            return `kuaishou://profile/${uid}`;
        default:
            return '';
    }
}
/**
 * 获取所有可能用于跳转的 URL 列表
 *
 * 优先级说明：
 * - B站 / 快手：scheme 优先（HarmonyOS 上 bilibili:// / kwai:// 可直达）
 * - 抖音：HTTPS 优先（HarmonyOS 版抖音不注册 snssdk1128:///aweme:// 等 scheme，
 *         需用 system browser 打开 HTTPS 页面，由页面触发 App 重定向）
 */
export function getJumpUrls(platform: string, uid: string, originalLink: string): string[] {
    const urls: string[] = [];
    if (platform === 'douyin') {
        // 抖音：仅用 HTTPS，由系统 openLink 自行处理 App Linking / 浏览器
        // 注：HarmonyOS 版抖音不注册 snssdk1128:// / aweme:// 等 scheme，故不尝试
        const realUrl = buildRealHttpsUrl(platform, uid);
        if (realUrl)
            urls.push(realUrl);
        if (originalLink && !urls.includes(originalLink))
            urls.push(originalLink);
    }
    else if (platform === 'kuaishou') {
        // 快手：scheme 优先（直达 App）
        const mainScheme = getSchemeLink(platform, uid);
        if (mainScheme)
            urls.push(mainScheme);
        const altScheme = getAlternativeSchemeLink(platform, uid);
        if (altScheme && altScheme !== mainScheme)
            urls.push(altScheme);
        const realUrl = buildRealHttpsUrl(platform, uid);
        if (realUrl && !urls.includes(realUrl))
            urls.push(realUrl);
        if (originalLink && !urls.includes(originalLink))
            urls.push(originalLink);
    }
    else {
        // B站：HTTPS 优先（用 openLink 走 App Linking，可跳过浏览器引导页直达 App）
        // 若 B站鸿蒙版配了 domainVerify，openLink 可直达 App；未配则显示 m. 版内容页
        const realUrl = buildRealHttpsUrl(platform, uid);
        if (realUrl)
            urls.push(realUrl);
        // scheme 兜底（部分 B站版本可能注册了 bilibili://）
        const mainScheme = getSchemeLink(platform, uid);
        if (mainScheme)
            urls.push(mainScheme);
        const altScheme = getAlternativeSchemeLink(platform, uid);
        if (altScheme && altScheme !== mainScheme)
            urls.push(altScheme);
        if (originalLink && !urls.includes(originalLink))
            urls.push(originalLink);
    }
    return urls;
}
function buildRealHttpsUrl(platform: string, uid: string): string {
    switch (platform) {
        case 'bilibili':
            // 用 m. 移动版域名，避免桌面版 space.bilibili.com 在手机浏览器弹出"打开App"引导页
            return `https://m.bilibili.com/space/${uid}`;
        case 'douyin':
            return `https://www.douyin.com/user/${uid}`;
        case 'kuaishou':
            return `https://www.kuaishou.com/profile/${uid}`;
        default:
            return '';
    }
}
/**
 * 统一智能跳转函数 — 按平台最优策略尝试所有可能的跳转方式
 *
 * 对每个 URL 按优先级尝试：
 *   ① custom scheme → startAbility 直达 App
 *   ② HTTPS → openLink 走 App Linking + 浏览器兜底
 *
 * 适用所有平台：调用方只需提供 platform + uid，无需关心各平台 scheme 差异。
 *
 * @param ctx      UIAbilityContext
 * @param platform 平台标识（bilibili / douyin / kuaishou）
 * @param uid      平台用户 ID
 * @param originalLink 原始用户输入链接（可选，作最终兜底）
 * @returns true=任一方式跳转成功
 */
export async function smartJump(ctx: common.UIAbilityContext, platform: string, uid: string, originalLink?: string): Promise<boolean> {
    const urls = getJumpUrls(platform, uid, originalLink || '');
    for (const url of urls) {
        // custom scheme → startAbility
        if (url.includes('://') && !url.startsWith('http://') && !url.startsWith('https://')) {
            try {
                const want: Want = {
                    action: 'ohos.want.action.viewData',
                    entities: ['entity.system.browsable'],
                    uri: url
                };
                await ctx.startAbility(want);
                console.info('[smartJump] scheme 直达成功:', url);
                return true;
            }
            catch (e) {
                console.info('[smartJump] scheme 失败:', url, JSON.stringify(e));
                // 不返回 false → 继续尝试下一个 URL
            }
            continue;
        }
        // HTTPS → openLink（系统处理 App Linking / 浏览器兜底）
        try {
            await ctx.openLink(url, {
                appLinkingOnly: false,
                parameters: { source: 'UPSaveList' }
            });
            console.info('[smartJump] openLink 成功:', url);
            return true;
        }
        catch (e) {
            console.info('[smartJump] openLink 失败:', url, JSON.stringify(e));
        }
    }
    return false;
}
