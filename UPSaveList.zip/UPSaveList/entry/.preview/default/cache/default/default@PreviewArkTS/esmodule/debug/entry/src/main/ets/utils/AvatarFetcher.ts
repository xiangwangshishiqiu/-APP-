import http from "@ohos:net.http";
// ===== 各平台ID提取 =====
// ===== 导出的短链解析工具函数（供 ShortLinkResolver 复用） =====
// 提取 B站 UID 支持格式：
//   space.bilibili.com/{uid}           — 桌面端主页
//   space.bilibili.com/{uid}/dynamic   — 带子路径
//   m.bilibili.com/space/{uid}         — 移动端
export function extractBilibiliUid(url: string): string | null {
    const match = url.match(/(?:space|m)\.bilibili\.com\/(?:space\/)?(\d+)/);
    return match ? match[1] : null;
}
// 提取抖音 sec_uid 支持格式：
//   douyin.com/user/{sec_uid}       — 标准用户主页
//   v.douyin.com/xxxxx              — 短链接（由 resolveVdouyinUrl 解析）
//   douyin.com/note/{id}            — 视频/笔记页（需从页面解析）
export function extractDouyinSecUid(url: string): string | null {
    const match = url.match(/douyin\.com\/user\/([^\/\?#]+)/);
    return match ? match[1] : null;
}
// ===== 从任意 HTML 中提取抖音 sec_uid（多策略） =====
function extractSecUidFromHtml(html: string): string | null {
    // 策略1：douyin.com/user/{sec_uid} 完整 URL
    const urlMatch = html.match(/douyin\.com\/user\/([^\/\?#\"\'\s<>]+)/);
    if (urlMatch && urlMatch[1])
        return urlMatch[1];
    // 策略2：JSON 中 "sec_uid":"xxx"
    const jsonMatch = html.match(/\"sec_uid\"\s*:\s*\"([^\"]+)\"/);
    if (jsonMatch && jsonMatch[1])
        return jsonMatch[1];
    // 策略3：__INITIAL_STATE__ 全局 JSON 中的 sec_uid
    // window.__INITIAL_STATE__={... "sec_uid":"xxx" ...}
    const initState = html.match(/window\.__INITIAL_STATE__\s*=\s*({[^;]+})/);
    if (initState && initState[1]) {
        try {
            const parsed = JSON.parse(initState[1]) as Record<string, Object>;
            const user = parsed['user'] as Record<string, Object> | undefined;
            if (user && user['sec_uid'])
                return String(user['sec_uid']);
            const profile = parsed['profile'] as Record<string, Object> | undefined;
            if (profile && profile['secUid'])
                return String(profile['secUid']);
        }
        catch (_) { /* ignore parse error */ }
    }
    // 策略4：og:url / canonical 中的 /user/{sec_uid}
    const ogUrl = html.match(/<meta\s+property=\"og:url\"\s+content=\"([^\"]+)\"/);
    const canonical = html.match(/<link\s+rel=\"canonical\"\s+href=\"([^\"]+)\"/);
    const linkUrl = ogUrl?.[1] || canonical?.[1];
    if (linkUrl) {
        const uid = linkUrl.match(/douyin\.com\/user\/([^\/\?#]+)/);
        if (uid && uid[1])
            return uid[1];
    }
    // 策略5：任意 <a> 或 data-* 中的 /user/{sec_uid}
    const attrMatch = html.match(/\/user\/([a-zA-Z0-9_\-]{10,})/);
    if (attrMatch && attrMatch[1])
        return attrMatch[1];
    return null;
}
// ===== 抖音短链接解析（v.douyin.com → sec_uid） =====
// 多层策略递进，应对抖音反爬机制：
//   策略A：maxRedirects=0 → 拿 302 Location 头 → 直接提取 sec_uid
//   策略B：跟随重定向 → 解析 HTML → 多模式提取
//   策略C：HTML 兜底 → 误码降级 fetch 同域名
//
export async function resolveVdouyinUrl(shortUrl: string): Promise<string | null> {
    // ---------- 策略A：maxRedirects=0 → 拿 302 Location 头 ----------
    try {
        const uid = await resolveVdouyinViaRedirect(shortUrl);
        if (uid)
            return uid;
    }
    catch (_) { /* fallback */ }
    // ---------- 策略B：跟随重定向 → 解析 HTML ----------
    try {
        const uid = await resolveVdouyinViaHtml(shortUrl);
        if (uid)
            return uid;
    }
    catch (_) { /* fallback */ }
    // ---------- 策略C：尝试 iesdouyin 域名 ----------
    try {
        const altUrl = shortUrl.replace('v.douyin.com', 'www.iesdouyin.com');
        const uid = await resolveVdouyinViaHtml(altUrl);
        if (uid)
            return uid;
    }
    catch (_) { /* fallback */ }
    return null;
}
// 策略A：maxRedirects=0 → 从 302 Location 头中提取 sec_uid
async function resolveVdouyinViaRedirect(shortUrl: string): Promise<string | null> {
    const httpRequest = http.createHttp();
    try {
        const response = await httpRequest.request(shortUrl, {
            method: http.RequestMethod.GET,
            maxRedirects: 0,
            header: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'zh-CN,zh;q=0.9'
            },
            connectTimeout: 10000,
            readTimeout: 10000
        });
        if (response.responseCode >= 300 && response.responseCode < 400) {
            const headers = response.header as Record<string, Object>;
            const location: string | undefined = typeof headers['Location'] === 'string' ? headers['Location'] as string :
                typeof headers['location'] === 'string' ? headers['location'] as string :
                    undefined;
            if (location) {
                // 302 到 douyin.com/user/{sec_uid}？直接提取
                const uid = extractDouyinSecUid(location);
                if (uid)
                    return uid;
                // 也可能是其他格式，从 location 中搜索 /user/{sec_uid}
                const uidMatch = location.match(/\/user\/([^\/\?#]+)/);
                if (uidMatch && uidMatch[1])
                    return uidMatch[1];
            }
        }
        return null;
    }
    finally {
        httpRequest.destroy();
    }
}
// 策略B：跟随重定向 → 解析 HTML
async function resolveVdouyinViaHtml(shortUrl: string): Promise<string | null> {
    const httpRequest = http.createHttp();
    try {
        const response = await httpRequest.request(shortUrl, {
            method: http.RequestMethod.GET,
            header: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'zh-CN,zh;q=0.9',
                'Referer': 'https://www.douyin.com/',
                'sec-ch-ua': '"Google Chrome";v="122", "Chromium";v="122", "Not?A_Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"'
            },
            connectTimeout: 15000,
            readTimeout: 15000
        });
        if (response.responseCode !== 200)
            return null;
        const html = response.result as string;
        if (!html)
            return null;
        return extractSecUidFromHtml(html);
    }
    finally {
        httpRequest.destroy();
    }
}
// 提取快手 user_id（kuaishou.com/profile/{user_id}）
export function extractKuaishouUserId(url: string): string | null {
    const match = url.match(/kuaishou\.com\/(?:profile|user)\/([^\/\?#]+)/);
    return match ? match[1] : null;
}
// ===== HTTP GET 工具 =====
export async function httpGet(url: string): Promise<string | null> {
    const httpRequest = http.createHttp();
    try {
        const response = await httpRequest.request(url, {
            method: http.RequestMethod.GET,
            header: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            connectTimeout: 10000,
            readTimeout: 10000
        });
        if (response.responseCode === 200) {
            return response.result as string;
        }
        return null;
    }
    catch (e) {
        console.error('[AvatarFetcher] httpGet error:', JSON.stringify(e));
        return null;
    }
    finally {
        httpRequest.destroy();
    }
}
// ===== B站 b23.tv 短链接解析 → UID =====
// 项目 targetSdkVersion=6.1.1(24), compatibleSdkVersion=6.1.0(23)
// API 23+ 支持 HttpRequestOptions.maxRedirects
//
// 核心方案（API 23+）：maxRedirects: 0 → 禁止跟随 302 重定向
// → 直接拿到 b23.tv 的 302 Location 头
// → 从 Location URL 中提取 UID（空间页）或 BVID（视频页）
// → 无需 HTML，彻底绕过反爬问题
//
// 兜底方案：跟随重定向解析 HTML（老版本或方式A失败时）
export async function resolveB23Url(shortUrl: string): Promise<string | null> {
    // 方式A：maxRedirects=0 → 直接拿 302 Location（API 23+）
    try {
        const uid = await resolveB23ViaRedirect(shortUrl);
        if (uid)
            return uid;
    }
    catch (_) { /* fallback to HTML */ }
    // 方式B：兜底 — 跟随重定向解析 HTML
    return resolveB23ViaHtml(shortUrl);
}
// 方式A：maxRedirects = 0 禁止跟随重定向 → 获取 302 Location 头
async function resolveB23ViaRedirect(shortUrl: string): Promise<string | null> {
    const httpRequest = http.createHttp();
    try {
        const response = await httpRequest.request(shortUrl, {
            method: http.RequestMethod.GET,
            maxRedirects: 0,
            header: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
            },
            connectTimeout: 15000,
            readTimeout: 15000
        });
        // 处理 3xx 重定向 → 提取 Location 头
        if (response.responseCode >= 300 && response.responseCode < 400) {
            const headers = response.header as Record<string, Object>;
            const location: string | undefined = typeof headers['Location'] === 'string' ? headers['Location'] as string :
                typeof headers['location'] === 'string' ? headers['location'] as string :
                    undefined;
            if (location) {
                // ① 空间页 → 直接拿 UID
                const uid = extractBilibiliUid(location);
                if (uid)
                    return uid;
                // ② 视频页 → 提取 BVID → 调 API 拿 owner.mid
                const bvidMatch = location.match(/\/video\/(BV[A-Za-z0-9]+)/);
                if (bvidMatch && bvidMatch[1]) {
                    const apiResult = await httpGet(`https://api.bilibili.com/x/web-interface/view?bvid=${bvidMatch[1]}`);
                    if (apiResult) {
                        try {
                            const json = JSON.parse(apiResult) as Record<string, Object>;
                            const owner = (json['data'] as Record<string, Object> | undefined)?.['owner'] as Record<string, Object> | undefined;
                            const ownerMid = owner?.['mid'];
                            if (ownerMid !== undefined && ownerMid !== null)
                                return String(ownerMid);
                        }
                        catch (_) { /* ignore parse error */ }
                    }
                }
            }
        }
        return null;
    }
    finally {
        httpRequest.destroy();
    }
}
// 方式B：兜底 — 跟随重定向 → 解析 HTML（带完整浏览器头 + Cookie 绕过反爬）
async function resolveB23ViaHtml(shortUrl: string): Promise<string | null> {
    const httpRequest = http.createHttp();
    try {
        const response = await httpRequest.request(shortUrl, {
            method: http.RequestMethod.GET,
            header: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                'Referer': 'https://www.bilibili.com/',
                'sec-ch-ua': '"Google Chrome";v="122", "Chromium";v="122", "Not?A_Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'DNT': '1',
                'Upgrade-Insecure-Requests': '1',
                'Cookie': 'buvid3=' + generateBuvid3() + '; b_nut=' + Date.now() + '; b_lsid=' + generateBuvid3()
            },
            connectTimeout: 15000,
            readTimeout: 15000
        });
        if (response.responseCode !== 200)
            return null;
        const html = response.result as string;
        if (!html)
            return null;
        // 策略①：空间页链接
        const spaceMatch = html.match(/space\.bilibili\.com\/(\d+)/);
        if (spaceMatch && spaceMatch[1])
            return spaceMatch[1];
        const mobileMatch = html.match(/m\.bilibili\.com\/space\/(\d+)/);
        if (mobileMatch && mobileMatch[1])
            return mobileMatch[1];
        // 策略②：内嵌 JSON "mid":{uid}
        const midMatch = html.match(/"mid"\s*:\s*(\d{5,})/);
        if (midMatch && midMatch[1])
            return midMatch[1];
        // 策略③：BVID → 视频 API → owner.mid
        const bvidMatch = html.match(/"bvid"\s*:\s*"(BV[A-Za-z0-9]+)"/);
        if (bvidMatch && bvidMatch[1]) {
            const apiResult = await httpGet(`https://api.bilibili.com/x/web-interface/view?bvid=${bvidMatch[1]}`);
            if (apiResult) {
                try {
                    const json = JSON.parse(apiResult) as Record<string, Object>;
                    const owner = (json['data'] as Record<string, Object> | undefined)?.['owner'] as Record<string, Object> | undefined;
                    const ownerMid = owner?.['mid'];
                    if (ownerMid !== undefined && ownerMid !== null)
                        return String(ownerMid);
                }
                catch (_) { /* ignore */ }
            }
        }
        // 策略④：og:url / canonical → 再提取
        const ogUrl = html.match(/<meta\s+property="og:url"\s+content="([^"]+)"/);
        const canonical = html.match(/<link\s+rel="canonical"\s+href="([^"]+)"/);
        const finalUrl = ogUrl?.[1] || canonical?.[1];
        if (finalUrl) {
            const uid = extractBilibiliUid(finalUrl);
            if (uid)
                return uid;
            const bvid = finalUrl.match(/\/video\/(BV[A-Za-z0-9]+)/);
            if (bvid && bvid[1]) {
                const apiResult = await httpGet(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid[1]}`);
                if (apiResult) {
                    try {
                        const json = JSON.parse(apiResult) as Record<string, Object>;
                        const owner = (json['data'] as Record<string, Object> | undefined)?.['owner'] as Record<string, Object> | undefined;
                        const ownerMid = owner?.['mid'];
                        if (ownerMid !== undefined && ownerMid !== null)
                            return String(ownerMid);
                    }
                    catch (_) { /* ignore */ }
                }
            }
        }
        return null;
    }
    catch (e) {
        console.error('[AvatarFetcher] resolveB23ViaHtml error:', JSON.stringify(e));
        return null;
    }
    finally {
        httpRequest.destroy();
    }
}
// 生成 B站风格 UUID 用于 Cookie（buvid3 格式）
function generateBuvid3(): string {
    const hex = (): string => Math.floor(Math.random() * 16).toString(16);
    const seg = (len: number): string => {
        let result = '';
        for (let i = 0; i < len; i++) {
            result += hex();
        }
        return result;
    };
    return seg(8) + '-' + seg(4) + '-' + seg(4) + '-' + seg(4) + '-' + seg(12);
}
// ===== B站头像获取（通过公开 API） =====
async function fetchBilibiliAvatar(url: string): Promise<string | null> {
    let uid = extractBilibiliUid(url);
    // 如果是 b23.tv 短链接，走解析流程获取 UID
    if (!uid && url.includes('b23.tv')) {
        uid = await resolveB23Url(url);
    }
    if (!uid)
        return null;
    const apiUrl = `https://api.bilibili.com/x/space/acc/info?mid=${uid}`;
    const result = await httpGet(apiUrl);
    if (!result)
        return null;
    try {
        const json = JSON.parse(result) as Record<string, Object>;
        const data = json['data'] as Record<string, Object> | undefined;
        if (json['code'] === 0 && data && data['face']) {
            return data['face'] as string;
        }
    }
    catch (e) {
        console.error('[AvatarFetcher] parse bilibili error:', JSON.stringify(e));
    }
    return null;
}
// ===== 抖音头像获取（通过 iesdouyin 公开 API） =====
// 使用官方 API：GET /web/api/v2/user/info/?sec_uid={sec_uid}
// 返回结构化 JSON，稳定可靠，无需解析 HTML
async function fetchDouyinAvatar(url: string): Promise<string | null> {
    let secUid = extractDouyinSecUid(url);
    // 如果是 v.douyin.com 短链接，走解析流程获取 sec_uid
    if (!secUid && url.includes('v.douyin.com')) {
        secUid = await resolveVdouyinUrl(url);
    }
    if (!secUid)
        return null;
    // 方案一：通过 iesdouyin API 获取头像（结构化 JSON，稳定可靠）
    const apiUrl = `https://www.iesdouyin.com/web/api/v2/user/info/?sec_uid=${secUid}`;
    const result = await httpGet(apiUrl);
    if (result) {
        try {
            const json = JSON.parse(result) as Record<string, Object>;
            if (json['status_code'] === 0) {
                const userInfo = json['user_info'] as Record<string, Object> | undefined;
                if (userInfo) {
                    // 优先用最大尺寸头像 avatar_larger，依次降级 avatar_medium → avatar_thumb
                    const avatarLarger = userInfo['avatar_larger'] as Record<string, string[]> | undefined;
                    const avatarMedium = userInfo['avatar_medium'] as Record<string, string[]> | undefined;
                    const avatarThumb = userInfo['avatar_thumb'] as Record<string, string[]> | undefined;
                    const target = avatarLarger || avatarMedium || avatarThumb;
                    if (target && target['url_list'] && target['url_list'].length > 0) {
                        return target['url_list'][0]; // 取第一个 CDN 地址
                    }
                }
            }
        }
        catch (e) {
            console.error('[AvatarFetcher] parse douyin api error:', JSON.stringify(e));
        }
    }
    // 方案二（兜底）：API 失败时降级从页面 og:image 提取
    const html = await httpGet(url);
    if (!html)
        return null;
    const ogImageMatch = html.match(/<meta\s+property=\"og:image\"\s+content=\"([^\\\"]+)\\\"/);
    if (ogImageMatch && ogImageMatch[1]) {
        return ogImageMatch[1];
    }
    return null;
}
// ===== 快手头像获取（解析页面嵌入数据） =====
async function fetchKuaishouAvatar(url: string): Promise<string | null> {
    const userId = extractKuaishouUserId(url);
    if (!userId)
        return null;
    // 尝试从页面 HTML 中提取
    const html = await httpGet(url);
    if (!html)
        return null;
    // 搜索 avatar 图片 URL 模式
    const avatarMatches = html.match(/https?:[^\"']*(?:avatar|Avatar)[^\"']*(?:\.jpg|\.png|\.jpeg|\.webp)/g);
    if (avatarMatches && avatarMatches.length > 0) {
        return avatarMatches[0];
    }
    // 尝试从 og:image meta 标签提取
    const ogImageMatch = html.match(/<meta\s+property=\"og:image\"\s+content=\"([^\\\"]+)\\\"/);
    if (ogImageMatch && ogImageMatch[1]) {
        return ogImageMatch[1];
    }
    return null;
}
// ===== 对外统一接口 =====
/**
 * 根据平台和博主主页链接，自动解析获取头像 URL
 * @param platform 平台标识（bilibili / douyin / kuaishou）
 * @param url 博主主页链接
 * @returns 头像 URL，获取失败返回 null
 */
export async function fetchAvatarFromUrl(platform: string, url: string): Promise<string | null> {
    switch (platform) {
        case 'bilibili':
            return fetchBilibiliAvatar(url);
        case 'douyin':
            return fetchDouyinAvatar(url);
        case 'kuaishou':
            return fetchKuaishouAvatar(url);
        default:
            return null;
    }
}
