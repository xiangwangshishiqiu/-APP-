if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface KuaishouPage_Params {
    creatorsRaw?: string;
    showCreatorId?: boolean;
    TAG?: string;
}
import router from "@ohos:router";
import type common from "@ohos:app.ability.common";
import type Want from "@ohos:app.ability.Want";
import JSON from "@ohos:util.json";
import { deleteCreatorByIndex } from "@normalized:N&&&entry/src/main/ets/models/CreatorModel&";
import type { CreatorInfo } from "@normalized:N&&&entry/src/main/ets/models/CreatorModel&";
import { AvatarComponent } from "@normalized:N&&&entry/src/main/ets/components/AvatarComponent&";
import pasteboard from "@ohos:pasteboard";
import { resolveLink } from "@normalized:N&&&entry/src/main/ets/utils/ShortLinkResolver&";
class KuaishouPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__creatorsRaw = this.createStorageProp('kuaishou_creators', '', "creatorsRaw");
        this.__showCreatorId = new ObservedPropertySimplePU(false, this, "showCreatorId");
        this.TAG = '[KuaishouPage]';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: KuaishouPage_Params) {
        if (params.showCreatorId !== undefined) {
            this.showCreatorId = params.showCreatorId;
        }
        if (params.TAG !== undefined) {
            this.TAG = params.TAG;
        }
    }
    updateStateVars(params: KuaishouPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__creatorsRaw.purgeDependencyOnElmtId(rmElmtId);
        this.__showCreatorId.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__creatorsRaw.aboutToBeDeleted();
        this.__showCreatorId.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __creatorsRaw: ObservedPropertyAbstractPU<string>;
    get creatorsRaw() {
        return this.__creatorsRaw.get();
    }
    set creatorsRaw(newValue: string) {
        this.__creatorsRaw.set(newValue);
    }
    private __showCreatorId: ObservedPropertySimplePU<boolean>; // 切换显示 ID / 链接
    get showCreatorId() {
        return this.__showCreatorId.get();
    }
    set showCreatorId(newValue: boolean) {
        this.__showCreatorId.set(newValue);
    }
    getCreatorList(): CreatorInfo[] {
        try {
            return this.creatorsRaw ? JSON.parse(this.creatorsRaw) as CreatorInfo[] : [];
        }
        catch (e) {
            return [];
        }
    }
    private TAG: string;
    // 点击博主 → 复制完整原文 + 拉起快手APP
    private async onClickJump(item: CreatorInfo): Promise<void> {
        const rawText: string = item.link;
        const context: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
        // 1. 复制完整原文到剪贴板
        try {
            const pb: pasteboard.SystemPasteboard = pasteboard.getSystemPasteboard();
            const data: pasteboard.PasteData = pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, rawText);
            pb.setData(data);
            console.info(this.TAG, '已复制原文:', rawText);
        }
        catch (e) {
            console.warn(this.TAG, '复制失败(不影响跳转):', JSON.stringify(e));
        }
        // 2. 从原文中提取链接
        const urlMatch: RegExpMatchArray | null = rawText.match(/https?:\/\/[^\s,，。、）)]+/);
        const jumpUrl: string = urlMatch ? urlMatch[0] : rawText;
        // 3. 优先使用 item.uid（ShortLinkResolver 解析后已填充）
        const itemUid: string | undefined = item.uid;
        if (itemUid) {
            this.trySchemes(context, itemUid);
            return;
        }
        // 4. 无 uid 尝试从 URL 提取 profile ID
        const profileMatch: RegExpMatchArray | null = jumpUrl.match(/kuaishou\.(?:com|cn)\/(?:profile|user)\/([^\/?#\s<>]+)/);
        if (profileMatch && profileMatch[1]) {
            this.trySchemes(context, profileMatch[1]);
            return;
        }
        // 5. 兜底A：动态解析短链接（兼容老数据，item.uid 为空的情况）
        try {
            const resolved = await resolveLink(jumpUrl);
            if (resolved && resolved.uid) {
                console.info(this.TAG, '动态解析成功, uid:', resolved.uid);
                this.trySchemes(context, resolved.uid);
                return;
            }
        }
        catch (e) {
            console.warn(this.TAG, '动态解析失败:', JSON.stringify(e));
        }
        // 6. 兜底B：openLink 让系统处理
        context.openLink(jumpUrl, { appLinkingOnly: false })
            .then(() => console.info(this.TAG, 'openLink 成功:', jumpUrl))
            .catch((e: Error) => console.warn(this.TAG, 'openLink 失败:', JSON.stringify(e)));
    }
    /** 用 kwai:// / ksnebula:// / kuaishou:// 逐个尝试拉起快手APP */
    private async trySchemes(context: common.UIAbilityContext, uid: string): Promise<void> {
        const schemes: string[] = [
            'kwai://profile/' + uid,
            'ksnebula://profile/' + uid,
            'kuaishou://profile/' + uid
        ];
        for (const scheme of schemes) {
            try {
                const want: Want = {
                    action: 'ohos.want.action.viewData',
                    entities: ['entity.system.browsable'],
                    uri: scheme
                };
                await context.startAbility(want);
                console.info(this.TAG, 'scheme 拉起成功:', scheme);
                return;
            }
            catch (e) {
                console.info(this.TAG, 'scheme 失败:', scheme, JSON.stringify(e));
            }
        }
        console.warn(this.TAG, '所有 scheme 均无法拉起快手APP:', uid);
    }
    // ===== 左滑删除按钮 =====
    deleteButton(index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(105:5)", "entry");
            Row.height('100%');
            Row.alignItems(VerticalAlign.Center);
            Row.justifyContent(FlexAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除');
            Button.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(106:7)", "entry");
            Button.width(72);
            Button.height('100%');
            Button.backgroundColor('#FF5252');
            Button.fontColor(Color.White);
            Button.fontSize(15);
            Button.borderRadius(0);
            Button.onClick(() => {
                deleteCreatorByIndex('kuaishou', index);
            });
        }, Button);
        Button.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(123:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // ===== 顶部导航 =====
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(125:7)", "entry");
            // ===== 顶部导航 =====
            Row.width('100%');
            // ===== 顶部导航 =====
            Row.padding({ left: 16, right: 16, top: 12, bottom: 12 });
            // ===== 顶部导航 =====
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(126:9)", "entry");
            Image.width(28);
            Image.height(28);
            Image.objectFit(ImageFit.Contain);
            Image.margin({ right: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('快手收藏');
            Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(131:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(134:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返回');
            Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(135:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#0A59F7');
            Text.onClick(() => {
                router.back();
            });
        }, Text);
        Text.pop();
        // ===== 顶部导航 =====
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`共收藏 ${this.getCreatorList().length} 位快手博主`);
            Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(146:7)", "entry");
            Text.fontSize(14);
            Text.fontColor('#999999');
            Text.width('100%');
            Text.padding({ left: 16, top: 12, bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 隐藏链接切换开关
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(153:7)", "entry");
            // 隐藏链接切换开关
            Row.width('100%');
            // 隐藏链接切换开关
            Row.justifyContent(FlexAlign.End);
            // 隐藏链接切换开关
            Row.padding({ right: 16, bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.showCreatorId ? '显示ID号' : '隐藏链接');
            Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(154:9)", "entry");
            Text.fontSize(13);
            Text.fontColor('#0A59F7');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.showCreatorId });
            Toggle.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(157:9)", "entry");
            Toggle.selectedColor('#0A59F7');
            Toggle.switchPointColor(Color.White);
            Toggle.onChange((isOn: boolean) => {
                this.showCreatorId = isOn;
            });
        }, Toggle);
        Toggle.pop();
        // 隐藏链接切换开关
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.getCreatorList().length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(169:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无收藏的博主');
                        Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(170:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#CCCCCC');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先在首页点击"解析博主"按钮');
                        Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(173:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#E0E0E0');
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(183:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.swipeAction({ end: this.deleteButton.bind(this, index) });
                                    ListItem.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(185:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(186:15)", "entry");
                                        Row.width('100%');
                                        Row.padding(16);
                                        Row.backgroundColor('#FFFFFF');
                                        Row.borderRadius(12);
                                        Row.shadow({ radius: 4, color: '#1A000000', offsetY: 2 });
                                        Row.onClick(() => {
                                            this.onClickJump(item);
                                        });
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        __Common__.create();
                                        __Common__.margin({ right: 12 });
                                    }, __Common__);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new 
                                                // 头像组件：自动处理网络加载 + 无网络降级文字占位
                                                AvatarComponent(this, {
                                                    avatarUrl: item.avatar,
                                                    name: item.name,
                                                    color: item.avatarColor,
                                                    avatarSize: 48
                                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/KuaishouPage.ets", line: 188, col: 17 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        avatarUrl: item.avatar,
                                                        name: item.name,
                                                        color: item.avatarColor,
                                                        avatarSize: 48
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "AvatarComponent" });
                                    }
                                    __Common__.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(196:17)", "entry");
                                        Column.alignItems(HorizontalAlign.Start);
                                        Column.layoutWeight(1);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(197:19)", "entry");
                                        Row.width('100%');
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.name);
                                        Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(198:21)", "entry");
                                        Text.fontSize(16);
                                        Text.fontWeight(FontWeight.Medium);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(201:21)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.followers);
                                        Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(202:21)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor('#FF6B35');
                                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                                        Text.backgroundColor('#FFF3E0');
                                        Text.borderRadius(10);
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.description);
                                        Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(211:19)", "entry");
                                        Text.fontSize(13);
                                        Text.fontColor('#666666');
                                        Text.margin({ top: 4 });
                                        Text.maxLines(2);
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        if (this.showCreatorId && item.creatorId) {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(item.creatorId);
                                                    Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(219:21)", "entry");
                                                    Text.fontSize(14);
                                                    Text.fontWeight(FontWeight.Medium);
                                                    Text.fontColor('#0A59F7');
                                                    Text.margin({ top: 4 });
                                                }, Text);
                                                Text.pop();
                                            });
                                        }
                                        else {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(item.link as string);
                                                    Text.debugLine("entry/src/main/ets/pages/KuaishouPage.ets(225:21)", "entry");
                                                    Text.fontSize(11);
                                                    Text.fontColor('#0A59F7');
                                                    Text.margin({ top: 4 });
                                                    Text.maxLines(1);
                                                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                                }, Text);
                                                Text.pop();
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    Column.pop();
                                    Row.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.getCreatorList(), forEachItemGenFunction, (item: CreatorInfo) => item.id, true, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "KuaishouPage";
    }
}
registerNamedRoute(() => new KuaishouPage(undefined, {}), "", { bundleName: "com.example.upsavelist", moduleName: "entry", pagePath: "pages/KuaishouPage", pageFullPath: "entry/src/main/ets/pages/KuaishouPage", integratedHsp: "false", moduleType: "followWithHap" });
