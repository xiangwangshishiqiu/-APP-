import type common from "@ohos:app.ability.common";
import type OpenLinkOptions from "@ohos:app.ability.OpenLinkOptions";
import type Want from "@ohos:app.ability.Want";
import http from "@ohos:net.http";
import router from "@ohos:router";
import { resolveLink } from "@normalized:N&&&entry/src/main/ets/utils/ShortLinkResolver&";
import { smartJump } from "@normalized:N&&&entry/src/main/ets/utils/SchemeLinkBuilder&";
import { isDeepLinkAllowed } from "@normalized:N&&&entry/src/main/ets/models/CreatorModel&";
const TAG: string = '[DeepLinkHandler]';
const DOMAIN_NUMBER: number = 0xFF00;
/** 预解析数据，传给 handleDeepLink 避免重新 HTTP 解析 */
export interface DeepLinkPreResolved {
    platform: string;
    uid: string;
    deepLink?: string;
    realUrl?: string;
}
/** __INITIAL_STATE__ 解析后的数据结构 */
interface InitialPageState {
    mid?: number | string;
    space?: SpaceInfo;
}
interface SpaceInfo {
    mid?: number | string;
}
/**
 * 为 openLink 构建可选的参数，可按需携带博主信息
 */
function buildOpenLinkOptions(): OpenLinkOptions {
    return {
        // appLinkingOnly: false → 优先尝试 App Linking 拉起目标 App，
        // 若失败则回退到默认浏览器打开网页（兼容性最好）
        appLinkingOnly: false,
        // 可附带自定义参数（目标 Ability 通过 want.parameters 获取）
        parameters: {
            source: 'UPSaveList'
        }
    };
}
/**
 * 自动抓取 B站引导页 HTML，提取其中藏着的 bilibili:// 深链
 * 绕过浏览器"打开App"引导页，直接用 startAbility 拉起 B站 App
 *
 * 多重策略：
 *   A. 已知 scheme 格式逐个尝试（覆盖主流 B站版本）
 *   B. HTTP 抓取页面，搜索 bilibili:// / intent:// 深链
 *   C. 提取 __INITIAL_STATE__ 中的 mid，自行构造深链
 */
async function tryExtractBiliDeepLink(ctx: common.UIAbilityContext, uid: string): Promise<boolean> {
    // ===== 策略 A：已知 scheme 格式快速尝试 =====
    // B站不同版本可能注册了不同的 scheme 格式
    const knownSchemes: string[] = [
        `bilibili://space/${uid}`,
        `bilibili://user/${uid}`,
        `bilibili://userinfo?mid=${uid}`,
        `bilibili://home/${uid}`,
        `bilibili://usercenter?mid=${uid}`
    ];
    for (const scheme of knownSchemes) {
        try {
            const want: Want = {
                action: 'ohos.want.action.viewData',
                entities: ['entity.system.browsable'],
                uri: scheme
            };
            await ctx.startAbility(want);
            console.info(TAG, '策略A 成功:', scheme);
            return true;
        }
        catch (_) {
            // 继续尝试下一种格式
        }
    }
    // ===== 策略 B：HTTP 抓取页面，搜索深链 =====
    const pageUrl = `https://m.bilibili.com/space/${uid}`;
    let httpRequest: http.HttpRequest | null = null;
    try {
        httpRequest = http.createHttp();
        const response = await httpRequest.request(pageUrl, {
            method: http.RequestMethod.GET,
            connectTimeout: 8000,
            readTimeout: 8000,
            header: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; HarmonyOS) AppleWebKit/537.36'
            }
        });
        if (response.responseCode === 200) {
            const html = response.result as string;
            let extractedDeepLink: string | null = null;
            // B1: 搜索 bilibili:// 开头的深链
            const biliMatch = html.match(new RegExp('bilibili://[a-zA-Z0-9_/?&=.-]+'));
            if (biliMatch && biliMatch[0]) {
                extractedDeepLink = biliMatch[0].trim();
            }
            // B2: 搜索 intent:// 格式的 URL（部分 B站版本使用）
            if (!extractedDeepLink) {
                const intentMatch = html.match(new RegExp('intent://[a-zA-Z0-9_/?&=.-:#;@]+'));
                if (intentMatch && intentMatch[0]) {
                    extractedDeepLink = intentMatch[0].trim();
                }
            }
            // B3: 提取 __INITIAL_STATE__ 中的真实 mid，自行构造深链
            if (!extractedDeepLink) {
                const initStateMatch = html.match(new RegExp('__INITIAL_STATE__\\s*=\\s*({.*?});'));
                if (initStateMatch && initStateMatch[1]) {
                    try {
                        const initState: InitialPageState = JSON.parse(initStateMatch[1]) as InitialPageState;
                        const realMid = initState.mid || initState.space?.mid;
                        if (realMid) {
                            const constructedSchemes = [
                                `bilibili://space/${realMid}`,
                                `bilibili://user/${realMid}`,
                                `bilibili://userinfo?mid=${realMid}`
                            ];
                            for (const s of constructedSchemes) {
                                try {
                                    const want: Want = {
                                        action: 'ohos.want.action.viewData',
                                        entities: ['entity.system.browsable'],
                                        uri: s
                                    };
                                    await ctx.startAbility(want);
                                    console.info(TAG, '策略B3 成功:', s);
                                    return true;
                                }
                                catch (_) {
                                    // 继续
                                }
                            }
                        }
                    }
                    catch (_) {
                        // JSON 解析失败，忽略
                    }
                }
            }
            // 如果找到了深链（B1/B2），尝试拉起
            if (extractedDeepLink) {
                console.info(TAG, '策略B 提取到深链:', extractedDeepLink);
                try {
                    const want: Want = {
                        action: 'ohos.want.action.viewData',
                        entities: ['entity.system.browsable'],
                        uri: extractedDeepLink
                    };
                    await ctx.startAbility(want);
                    console.info(TAG, '策略B 拉起成功');
                    return true;
                }
                catch (e) {
                    console.info(TAG, '策略B 拉起失败:', JSON.stringify(e));
                }
            }
            else {
                console.info(TAG, '策略B 未找到深链');
            }
        }
        else {
            console.info(TAG, '策略B 请求失败 HTTP:', response.responseCode);
        }
    }
    catch (e) {
        console.info(TAG, '策略B 异常:', JSON.stringify(e));
    }
    finally {
        if (httpRequest) {
            httpRequest.destroy();
        }
    }
    return false;
}
// ===== 尝试通过 scheme 或 openLink 跳转 =====
async function tryOpenUrl(ctx: common.UIAbilityContext, url: string): Promise<boolean> {
    // 自定义 scheme（bilibili://, kuaishou://）
    if (url.includes('://') && !url.startsWith('http://') && !url.startsWith('https://')) {
        try {
            const want: Want = {
                action: 'ohos.want.action.viewData',
                entities: ['entity.system.browsable'],
                uri: url
            };
            await ctx.startAbility(want);
            console.info(TAG, 'startAbility 直达:', url);
            return true;
        }
        catch (e) {
            console.info(TAG, 'startAbility 失败:', JSON.stringify(e));
        }
        // scheme 失败后，不再用 openLink 尝试（避免系统二次弹窗）
        return false;
    }
    // HTTP/HTTPS 链接用 openLink 打开（系统自行处理 App Linking / 浏览器兜底）
    try {
        await ctx.openLink(url, buildOpenLinkOptions());
        console.info(TAG, 'openLink 成功:', url);
        return true;
    }
    catch (e) {
        console.info(TAG, 'openLink 失败:', JSON.stringify(e));
    }
    return false;
}
// ===== 一层层尝试所有 URL =====
async function tryAllUrls(ctx: common.UIAbilityContext, urls: string[]): Promise<boolean> {
    for (const url of urls) {
        const ok = await tryOpenUrl(ctx, url);
        if (ok)
            return true;
    }
    return false;
}
// ===== B站专属：多策略逐级尝试，完全绕过浏览器引导页 =====
// 优先级：
//   1. openLink(appLinkingOnly: true)  → B站配了 App Linking 则直达 App
//   2. startAbility(bilibili://*)       → B站注册了 scheme 则直达 App
//   3. HTML 自动提取深链                → 从引导页抓取 bilibili:// 深链
//   4. Web 桥接页兜底                   → 嵌入 Web 组件拦截 bilibili:// 导航
async function tryBiliJump(ctx: common.UIAbilityContext, uid: string): Promise<boolean> {
    const httpsUrl = `https://m.bilibili.com/space/${uid}`;
    // ===== 策略 1: App Linking =====
    try {
        await ctx.openLink(httpsUrl, { appLinkingOnly: true, parameters: { source: 'UPSaveList' } });
        console.info(TAG, '策略1 App Linking 成功');
        return true;
    }
    catch (e) {
        console.info(TAG, '策略1 App Linking 不可用:', JSON.stringify(e));
    }
    // ===== 策略 2: 已知 scheme 格式逐个尝试 =====
    const schemes = [
        `bilibili://space/${uid}`,
        `bilibili://user/${uid}`,
        `bilibili://userinfo?mid=${uid}`,
        `bilibili://home/${uid}`,
        `bilibili://usercenter?mid=${uid}`
    ];
    for (const scheme of schemes) {
        try {
            const want: Want = {
                action: 'ohos.want.action.viewData',
                entities: ['entity.system.browsable'],
                uri: scheme
            };
            await ctx.startAbility(want);
            console.info(TAG, '策略2 scheme 成功:', scheme);
            return true;
        }
        catch (_) {
        }
    }
    // ===== 策略 3: HTML 自动提取深链 =====
    const extracted = await tryExtractBiliDeepLink(ctx, uid);
    if (extracted)
        return true;
    // ===== 策略 4: Web 桥接页兜底 =====
    // 嵌入 ArkWeb 组件加载 B站移动端页面，靠真实浏览器引擎拦截 bilibili:// 导航
    try {
        await router.pushUrl({
            url: 'pages/WebBridgePage',
            params: { uid: uid }
        });
        console.info(TAG, '策略4 Web桥接页已打开:', httpsUrl);
        return true;
    }
    catch (e) {
        console.info(TAG, '策略4 Web桥接页导航失败:', JSON.stringify(e));
        // 终极兜底：尝试系统浏览器
        try {
            await ctx.openLink(httpsUrl, { appLinkingOnly: false });
            return true;
        }
        catch (_) { }
    }
    return false;
}
// ===== 抖音专属：多策略逐级尝试，绕过浏览器中间页直接拉 App =====
// 抖音在 HarmonyOS 上通常不走 App Linking / scheme 注册，
// 但 douyin.com / iesdouyin.com 页面 HTML 中藏有 douyin:// / snssdk1128:// 等深链，
// 通过 HTTP 提取后可直接 startAbility 拉起抖音 App。
//
// 优先级：
//   1. openLink(appLinkingOnly: true)  → 配了 App Linking 则直达
//   2. startAbility(snssdk1128://*)     → 抖音原生 scheme
//   3. startAbility(aweme://*)          → 备选 scheme
//   4. startAbility(douyin://*)         → 通用深链 scheme
//   5. HTTP 抓取 douyin.com 页面       → 提取 HTML 中的深链
//   6. openLink(appLinkingOnly: false)  → 浏览器兜底
async function tryDouyinJump(ctx: common.UIAbilityContext, uid: string): Promise<boolean> {
    const httpsUrl = `https://www.douyin.com/user/${uid}`;
    // ===== 策略 1: App Linking =====
    try {
        await ctx.openLink(httpsUrl, { appLinkingOnly: true, parameters: { source: 'UPSaveList' } });
        console.info(TAG, '抖音策略1 App Linking 成功');
        return true;
    }
    catch (e) {
        console.info(TAG, '抖音策略1 App Linking 不可用:', JSON.stringify(e));
    }
    // ===== 策略 2: 已知 scheme 格式逐个尝试 =====
    // HarmonyOS 版抖音可能注册了以下某个 scheme
    const schemes: string[] = [
        `snssdk1128://user/${uid}`,
        `aweme://user/${uid}`,
        `douyin://user/${uid}`
    ];
    for (const scheme of schemes) {
        try {
            const want: Want = {
                action: 'ohos.want.action.viewData',
                entities: ['entity.system.browsable'],
                uri: scheme
            };
            await ctx.startAbility(want);
            console.info(TAG, '抖音策略2 scheme 成功:', scheme);
            return true;
        }
        catch (_) {
        }
    }
    // ===== 策略 3: HTTP 抓取 douyin.com 页面，提取深链 =====
    let httpRequest: http.HttpRequest | null = null;
    try {
        httpRequest = http.createHttp();
        const response = await httpRequest.request(httpsUrl, {
            method: http.RequestMethod.GET,
            connectTimeout: 8000,
            readTimeout: 8000,
            header: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; HarmonyOS) AppleWebKit/537.36'
            }
        });
        if (response.responseCode === 200) {
            const html = response.result as string;
            let extractedDeepLink: string | null = null;
            // 3a: 搜索 snssdk1128:// 深链
            const sdkMatch = html.match(new RegExp('snssdk1128://[a-zA-Z0-9_/?&=.-]+'));
            if (sdkMatch && sdkMatch[0]) {
                extractedDeepLink = sdkMatch[0].trim();
            }
            // 3b: 搜索 douyin:// 深链
            if (!extractedDeepLink) {
                const dyMatch = html.match(new RegExp('douyin://[a-zA-Z0-9_/?&=.-]+'));
                if (dyMatch && dyMatch[0]) {
                    extractedDeepLink = dyMatch[0].trim();
                }
            }
            // 3c: 搜索 intent:// 格式
            if (!extractedDeepLink) {
                const intentMatch = html.match(new RegExp('intent://[a-zA-Z0-9_/?&=.-:#;@]+'));
                if (intentMatch && intentMatch[0]) {
                    extractedDeepLink = intentMatch[0].trim();
                }
            }
            if (extractedDeepLink) {
                console.info(TAG, '抖音策略3 提取到深链:', extractedDeepLink);
                try {
                    const want: Want = {
                        action: 'ohos.want.action.viewData',
                        entities: ['entity.system.browsable'],
                        uri: extractedDeepLink
                    };
                    await ctx.startAbility(want);
                    console.info(TAG, '抖音策略3 拉起成功');
                    return true;
                }
                catch (e) {
                    console.info(TAG, '抖音策略3 拉起失败:', JSON.stringify(e));
                }
            }
            else {
                console.info(TAG, '抖音策略3 页面中未找到深链');
            }
        }
        else {
            console.info(TAG, '抖音策略3 请求失败 HTTP:', response.responseCode);
        }
    }
    catch (e) {
        console.info(TAG, '抖音策略3 异常:', JSON.stringify(e));
    }
    finally {
        if (httpRequest) {
            httpRequest.destroy();
        }
    }
    // ===== 策略 4: 浏览器兜底 =====
    try {
        await ctx.openLink(httpsUrl, { appLinkingOnly: false, parameters: { source: 'UPSaveList' } });
        console.info(TAG, '抖音策略4 浏览器兜底成功:', httpsUrl);
        return true;
    }
    catch (e) {
        console.info(TAG, '抖音策略4 浏览器兜底也失败:', JSON.stringify(e));
    }
    return false;
}
// ===== 核心：跳转逻辑 =====
// 接受可选预解析数据，避免重复 HTTP 请求
export async function handleDeepLink(ctx: common.UIAbilityContext, originalLink: string, preResolved?: DeepLinkPreResolved): Promise<void> {
    if (!isDeepLinkAllowed()) {
        return;
    }
    // 优先使用预解析数据（跳过 resolveLink 网络请求）
    let platform: string | undefined = preResolved?.platform;
    let uid: string | undefined = preResolved?.uid;
    let realUrl: string | undefined = preResolved?.realUrl;
    // 没有预解析数据 → 从零解析
    if (!platform || !uid) {
        const resolved = await resolveLink(originalLink);
        if (resolved) {
            platform = resolved.platform;
            uid = resolved.uid;
            realUrl = resolved.realUrl;
        }
    }
    if (platform && uid) {
        if (platform === 'bilibili') {
            const ok = await tryBiliJump(ctx, uid);
            if (!ok) {
                console.warn(TAG, 'B站全部跳转策略均失败');
            }
            return;
        }
        if (platform === 'douyin') {
            // 抖音：直接走默认浏览器打开，不尝试 scheme / App Linking
            const targetUrl = realUrl || `https://www.douyin.com/user/${uid}`;
            try {
                await ctx.openLink(targetUrl, { appLinkingOnly: false });
                console.info(TAG, '抖音 浏览器打开成功:', targetUrl);
            }
            catch (e) {
                console.warn(TAG, '抖音 浏览器打开失败:', JSON.stringify(e));
            }
            return;
        }
        // 快手及其他平台：用 smartJump（统一策略，先尝试 scheme 拉起APP，失败降级浏览器）
        const ok = await smartJump(ctx, platform, uid, realUrl || originalLink);
        if (!ok) {
            console.warn(TAG, platform + ' 全部跳转策略均失败');
        }
    }
    else {
        // 平台/UID 都未知 → 直接把原始链接丢给系统（浏览器兜底）
        await tryOpenUrl(ctx, originalLink);
    }
}
