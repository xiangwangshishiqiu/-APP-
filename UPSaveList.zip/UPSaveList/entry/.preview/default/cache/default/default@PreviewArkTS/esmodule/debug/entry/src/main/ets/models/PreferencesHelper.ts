import preferences from "@ohos:data.preferences";
import type common from "@ohos:app.ability.common";
// ===== 持久化存储键 =====
export interface PrefsKeys {
    BILIBILI_CREATORS: string;
    DOUYIN_CREATORS: string;
    KUAISHOU_CREATORS: string;
    PARSED_FLAG: string;
    DEEP_LINK_ALLOWED: string;
    PRIVACY_AGREED: string;
}
export const PREFS_KEYS: PrefsKeys = {
    BILIBILI_CREATORS: 'bilibili_creators',
    DOUYIN_CREATORS: 'douyin_creators',
    KUAISHOU_CREATORS: 'kuaishou_creators',
    PARSED_FLAG: 'creators_parsed_flag',
    DEEP_LINK_ALLOWED: 'deep_link_allowed',
    PRIVACY_AGREED: 'privacy_agreed'
};
const STORE_NAME = 'upsavelist_preferences';
let preferencesInstance: preferences.Preferences | null = null;
// ===== 初始化（在 EntryAbility 中调用） =====
export async function initPreferences(context: common.UIAbilityContext): Promise<void> {
    preferencesInstance = await preferences.getPreferences(context, STORE_NAME);
}
// ===== 通用读写 =====
export async function getString(key: string, defaultValue: string = ''): Promise<string> {
    if (!preferencesInstance)
        return defaultValue;
    return (await preferencesInstance.get(key, defaultValue)) as string;
}
export async function setString(key: string, value: string): Promise<void> {
    if (!preferencesInstance)
        return;
    await preferencesInstance.put(key, value);
    await preferencesInstance.flush();
}
export async function getBool(key: string, defaultValue: boolean = false): Promise<boolean> {
    if (!preferencesInstance)
        return defaultValue;
    return (await preferencesInstance.get(key, defaultValue)) as boolean;
}
export async function setBool(key: string, value: boolean): Promise<void> {
    if (!preferencesInstance)
        return;
    await preferencesInstance.put(key, value);
    await preferencesInstance.flush();
}
// ===== 启动时：从 Preferences 加载到 AppStorage =====
export async function loadAllToAppStorage(): Promise<void> {
    // 加载各平台博主数据
    const bilibiliData = await getString(PREFS_KEYS.BILIBILI_CREATORS, '[]');
    AppStorage.setOrCreate(PREFS_KEYS.BILIBILI_CREATORS, bilibiliData);
    const douyinData = await getString(PREFS_KEYS.DOUYIN_CREATORS, '[]');
    AppStorage.setOrCreate(PREFS_KEYS.DOUYIN_CREATORS, douyinData);
    const kuaishouData = await getString(PREFS_KEYS.KUAISHOU_CREATORS, '[]');
    AppStorage.setOrCreate(PREFS_KEYS.KUAISHOU_CREATORS, kuaishouData);
    // 加载解析标志
    const parsedFlag = await getBool(PREFS_KEYS.PARSED_FLAG, false);
    AppStorage.setOrCreate(PREFS_KEYS.PARSED_FLAG, parsedFlag);
    // 加载深度链接权限（默认开启）
    const deepLinkAllowed = await getBool(PREFS_KEYS.DEEP_LINK_ALLOWED, true);
    AppStorage.setOrCreate(PREFS_KEYS.DEEP_LINK_ALLOWED, deepLinkAllowed);
    // 加载隐私协议同意状态（默认未同意）
    const privacyAgreed = await getBool(PREFS_KEYS.PRIVACY_AGREED, false);
    AppStorage.setOrCreate(PREFS_KEYS.PRIVACY_AGREED, privacyAgreed);
}
