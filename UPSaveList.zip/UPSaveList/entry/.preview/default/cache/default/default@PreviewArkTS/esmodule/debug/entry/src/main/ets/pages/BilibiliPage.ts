if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BilibiliPage_Params {
    creatorsRaw?: string;
    showCreatorId?: boolean;
}
import router from "@ohos:router";
import type common from "@ohos:app.ability.common";
import JSON from "@ohos:util.json";
import { deleteCreatorByIndex } from "@normalized:N&&&entry/src/main/ets/models/CreatorModel&";
import type { CreatorInfo } from "@normalized:N&&&entry/src/main/ets/models/CreatorModel&";
import { AvatarComponent } from "@normalized:N&&&entry/src/main/ets/components/AvatarComponent&";
import { handleDeepLink } from "@normalized:N&&&entry/src/main/ets/utils/DeepLinkHandler&";
class BilibiliPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__creatorsRaw = this.createStorageProp('bilibili_creators', '', "creatorsRaw");
        this.__showCreatorId = new ObservedPropertySimplePU(false, this, "showCreatorId");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BilibiliPage_Params) {
        if (params.showCreatorId !== undefined) {
            this.showCreatorId = params.showCreatorId;
        }
    }
    updateStateVars(params: BilibiliPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__creatorsRaw.purgeDependencyOnElmtId(rmElmtId);
        this.__showCreatorId.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__creatorsRaw.aboutToBeDeleted();
        this.__showCreatorId.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __creatorsRaw: ObservedPropertyAbstractPU<string>;
    get creatorsRaw() {
        return this.__creatorsRaw.get();
    }
    set creatorsRaw(newValue: string) {
        this.__creatorsRaw.set(newValue);
    }
    private __showCreatorId: ObservedPropertySimplePU<boolean>; // 切换显示 ID / 链接
    get showCreatorId() {
        return this.__showCreatorId.get();
    }
    set showCreatorId(newValue: boolean) {
        this.__showCreatorId.set(newValue);
    }
    getCreatorList(): CreatorInfo[] {
        try {
            return this.creatorsRaw ? JSON.parse(this.creatorsRaw) as CreatorInfo[] : [];
        }
        catch (e) {
            return [];
        }
    }
    // 点击博主 → 传预解析数据给 handleDeepLink，避免重复 HTTP 请求
    async handleLinkClick(link: string, name: string, deepLink?: string, realUrl?: string, uid?: string): Promise<void> {
        const ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
        await handleDeepLink(ctx, link, {
            platform: 'bilibili',
            uid: uid || '',
            deepLink: deepLink,
            realUrl: realUrl
        });
    }
    // ===== 左滑删除按钮 =====
    deleteButton(index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(36:5)", "entry");
            Row.height('100%');
            Row.alignItems(VerticalAlign.Center);
            Row.justifyContent(FlexAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除');
            Button.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(37:7)", "entry");
            Button.width(72);
            Button.height('100%');
            Button.backgroundColor('#FF5252');
            Button.fontColor(Color.White);
            Button.fontSize(15);
            Button.borderRadius(0);
            Button.onClick(() => {
                deleteCreatorByIndex('bilibili', index);
            });
        }, Button);
        Button.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(54:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // ===== 顶部导航栏 =====
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(56:7)", "entry");
            // ===== 顶部导航栏 =====
            Row.width('100%');
            // ===== 顶部导航栏 =====
            Row.padding({ left: 16, right: 16, top: 12, bottom: 12 });
            // ===== 顶部导航栏 =====
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(57:9)", "entry");
            Image.width(28);
            Image.height(28);
            Image.objectFit(ImageFit.Contain);
            Image.margin({ right: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('B站收藏');
            Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(62:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(65:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返回');
            Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(66:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#0A59F7');
            Text.onClick(() => {
                router.back();
            });
        }, Text);
        Text.pop();
        // ===== 顶部导航栏 =====
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // ===== 博主数量提示 =====
            Text.create(`共收藏 ${this.getCreatorList().length} 位B站博主`);
            Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(78:7)", "entry");
            // ===== 博主数量提示 =====
            Text.fontSize(14);
            // ===== 博主数量提示 =====
            Text.fontColor('#999999');
            // ===== 博主数量提示 =====
            Text.width('100%');
            // ===== 博主数量提示 =====
            Text.padding({ left: 16, top: 12, bottom: 8 });
        }, Text);
        // ===== 博主数量提示 =====
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 隐藏链接切换开关
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(85:7)", "entry");
            // 隐藏链接切换开关
            Row.width('100%');
            // 隐藏链接切换开关
            Row.justifyContent(FlexAlign.End);
            // 隐藏链接切换开关
            Row.padding({ right: 16, bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.showCreatorId ? '显示ID号' : '隐藏链接');
            Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(86:9)", "entry");
            Text.fontSize(13);
            Text.fontColor('#0A59F7');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.showCreatorId });
            Toggle.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(89:9)", "entry");
            Toggle.selectedColor('#0A59F7');
            Toggle.switchPointColor(Color.White);
            Toggle.onChange((isOn: boolean) => {
                this.showCreatorId = isOn;
            });
        }, Toggle);
        Toggle.pop();
        // 隐藏链接切换开关
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // ===== 博主列表 =====
            if (this.getCreatorList().length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(102:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无收藏的博主');
                        Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(103:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#CCCCCC');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请先在首页点击"解析博主"按钮');
                        Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(106:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#E0E0E0');
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(116:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.swipeAction({ end: this.deleteButton.bind(this, index) });
                                    ListItem.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(118:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(119:15)", "entry");
                                        Row.width('100%');
                                        Row.padding(16);
                                        Row.backgroundColor('#FFFFFF');
                                        Row.borderRadius(12);
                                        Row.shadow({ radius: 4, color: '#1A000000', offsetY: 2 });
                                        Row.onClick(() => {
                                            this.handleLinkClick(item.link, item.name, item.deepLink, item.realUrl, item.uid);
                                        });
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        __Common__.create();
                                        __Common__.margin({ right: 12 });
                                    }, __Common__);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new 
                                                // 头像组件：自动处理网络加载 + 无网络降级文字占位
                                                AvatarComponent(this, {
                                                    avatarUrl: item.avatar,
                                                    name: item.name,
                                                    color: item.avatarColor,
                                                    avatarSize: 48
                                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/BilibiliPage.ets", line: 121, col: 17 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        avatarUrl: item.avatar,
                                                        name: item.name,
                                                        color: item.avatarColor,
                                                        avatarSize: 48
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "AvatarComponent" });
                                    }
                                    __Common__.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 信息区域
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(130:17)", "entry");
                                        // 信息区域
                                        Column.alignItems(HorizontalAlign.Start);
                                        // 信息区域
                                        Column.layoutWeight(1);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(131:19)", "entry");
                                        Row.width('100%');
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.name);
                                        Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(132:21)", "entry");
                                        Text.fontSize(16);
                                        Text.fontWeight(FontWeight.Medium);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(135:21)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.followers);
                                        Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(136:21)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor('#FF6B35');
                                        Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
                                        Text.backgroundColor('#FFF3E0');
                                        Text.borderRadius(10);
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.description);
                                        Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(145:19)", "entry");
                                        Text.fontSize(13);
                                        Text.fontColor('#666666');
                                        Text.margin({ top: 4 });
                                        Text.maxLines(2);
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        if (this.showCreatorId && item.creatorId) {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(item.creatorId);
                                                    Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(153:21)", "entry");
                                                    Text.fontSize(14);
                                                    Text.fontWeight(FontWeight.Medium);
                                                    Text.fontColor('#0A59F7');
                                                    Text.margin({ top: 4 });
                                                }, Text);
                                                Text.pop();
                                            });
                                        }
                                        else {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create((item.realUrl ?? item.deepLink ?? item.link) as string);
                                                    Text.debugLine("entry/src/main/ets/pages/BilibiliPage.ets(159:21)", "entry");
                                                    Text.fontSize(11);
                                                    Text.fontColor('#0A59F7');
                                                    Text.margin({ top: 4 });
                                                    Text.maxLines(1);
                                                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                                }, Text);
                                                Text.pop();
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    // 信息区域
                                    Column.pop();
                                    Row.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.getCreatorList(), forEachItemGenFunction, (item: CreatorInfo) => item.id, true, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "BilibiliPage";
    }
}
registerNamedRoute(() => new BilibiliPage(undefined, {}), "", { bundleName: "com.example.upsavelist", moduleName: "entry", pagePath: "pages/BilibiliPage", pageFullPath: "entry/src/main/ets/pages/BilibiliPage", integratedHsp: "false", moduleType: "followWithHap" });
