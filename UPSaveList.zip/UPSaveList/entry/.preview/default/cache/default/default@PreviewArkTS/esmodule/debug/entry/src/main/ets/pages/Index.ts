if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Example_Params {
    currentIndex?: number;
    isParsed?: boolean;
    biliCount?: number;
    douyinCount?: number;
    kuaishouCount?: number;
    isCheckingPermission?: boolean;
    permissionDenied?: boolean;
    isCheckingPrivacy?: boolean;
    isShowSheet?: boolean;
    isShowAgreement?: boolean;
    isShowPrivacy?: boolean;
    PERMISSION_NAME?: Permissions;
    dialogController?: CustomDialogController | null;
}
interface ParseLinkDialog_Params {
    controller?: CustomDialogController;
    linkUrl?: string;
    rawLinkInput?: string;
    creatorName?: string;
    creatorId?: string;
    isB23Link?: boolean;
    onConfirm?: (url: string, name: string, creatorId?: string) => void;
    onCancel?: () => void;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import abilityAccessCtrl from "@ohos:abilityAccessCtrl";
import bundleManager from "@ohos:bundle.bundleManager";
import type common from "@ohos:app.ability.common";
import type { Permissions } from "@ohos:abilityAccessCtrl";
import type { BusinessError } from "@ohos:base";
import { parseAndAddCreator, getCreatorCount, getPlatformChinese, STORAGE_KEYS } from "@normalized:N&&&entry/src/main/ets/models/CreatorModel&";
import { resolveLink } from "@normalized:N&&&entry/src/main/ets/utils/ShortLinkResolver&";
import { PREFS_KEYS, setBool } from "@normalized:N&&&entry/src/main/ets/models/PreferencesHelper&";
class ParseLinkDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.__linkUrl = new ObservedPropertySimplePU('', this, "linkUrl");
        this.__rawLinkInput = new ObservedPropertySimplePU('', this, "rawLinkInput");
        this.__creatorName = new ObservedPropertySimplePU('', this, "creatorName");
        this.__creatorId = new ObservedPropertySimplePU('', this, "creatorId");
        this.__isB23Link = new ObservedPropertySimplePU(false, this, "isB23Link");
        this.onConfirm = undefined;
        this.onCancel = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ParseLinkDialog_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.linkUrl !== undefined) {
            this.linkUrl = params.linkUrl;
        }
        if (params.rawLinkInput !== undefined) {
            this.rawLinkInput = params.rawLinkInput;
        }
        if (params.creatorName !== undefined) {
            this.creatorName = params.creatorName;
        }
        if (params.creatorId !== undefined) {
            this.creatorId = params.creatorId;
        }
        if (params.isB23Link !== undefined) {
            this.isB23Link = params.isB23Link;
        }
        if (params.onConfirm !== undefined) {
            this.onConfirm = params.onConfirm;
        }
        if (params.onCancel !== undefined) {
            this.onCancel = params.onCancel;
        }
    }
    updateStateVars(params: ParseLinkDialog_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__linkUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__rawLinkInput.purgeDependencyOnElmtId(rmElmtId);
        this.__creatorName.purgeDependencyOnElmtId(rmElmtId);
        this.__creatorId.purgeDependencyOnElmtId(rmElmtId);
        this.__isB23Link.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__linkUrl.aboutToBeDeleted();
        this.__rawLinkInput.aboutToBeDeleted();
        this.__creatorName.aboutToBeDeleted();
        this.__creatorId.aboutToBeDeleted();
        this.__isB23Link.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller?: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private __linkUrl: ObservedPropertySimplePU<string>;
    get linkUrl() {
        return this.__linkUrl.get();
    }
    set linkUrl(newValue: string) {
        this.__linkUrl.set(newValue);
    }
    private __rawLinkInput: ObservedPropertySimplePU<string>; // 完整的原始粘贴文本（抖音保留全文）
    get rawLinkInput() {
        return this.__rawLinkInput.get();
    }
    set rawLinkInput(newValue: string) {
        this.__rawLinkInput.set(newValue);
    }
    private __creatorName: ObservedPropertySimplePU<string>;
    get creatorName() {
        return this.__creatorName.get();
    }
    set creatorName(newValue: string) {
        this.__creatorName.set(newValue);
    }
    private __creatorId: ObservedPropertySimplePU<string>; // 用户手动输入的博主 ID 号（可选）
    get creatorId() {
        return this.__creatorId.get();
    }
    set creatorId(newValue: string) {
        this.__creatorId.set(newValue);
    }
    private __isB23Link: ObservedPropertySimplePU<boolean>;
    get isB23Link() {
        return this.__isB23Link.get();
    }
    set isB23Link(newValue: boolean) {
        this.__isB23Link.set(newValue);
    }
    private onConfirm?: (url: string, name: string, creatorId?: string) => void;
    private onCancel?: () => void;
    // 从混合文本中提取第一个 HTTP/HTTPS 超链接
    extractUrl(text: string): string | null {
        const urlRegex = /https?:\/\/[^\s,，。、）\)\]]+/g;
        const match = text.match(urlRegex);
        return match ? match[0] : null;
    }
    // 识别平台类型
    detectPlatform(url: string): string {
        if (url.includes('bilibili.com') || url.includes('b23.tv')) {
            return 'bilibili';
        }
        else if (url.includes('douyin.com') || url.includes('iesdouyin.com')) {
            return 'douyin';
        }
        else if (url.includes('kuaishou.com') || url.includes('kuaishou.cn')) {
            return 'kuaishou';
        }
        return '';
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(40:5)", "entry");
            Column.width('85%');
            Column.padding({ left: 20, right: 20 });
            Column.backgroundColor(Color.White);
            Column.borderRadius(16);
            Column.shadow({ radius: 20, color: '#33000000', offsetX: 0, offsetY: 4 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题
            Text.create('解析博主链接');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(42:7)", "entry");
            // 标题
            Text.fontSize(20);
            // 标题
            Text.fontWeight(FontWeight.Bold);
            // 标题
            Text.fontColor('#333333');
            // 标题
            Text.margin({ top: 20, bottom: 12 });
        }, Text);
        // 标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 说明文字
            Text.create('支持解析以下平台博主主页链接：');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(49:7)", "entry");
            // 说明文字
            Text.fontSize(14);
            // 说明文字
            Text.fontColor('#666666');
            // 说明文字
            Text.margin({ bottom: 8 });
        }, Text);
        // 说明文字
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 平台标签
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(55:7)", "entry");
            // 平台标签
            Row.margin({ bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(56:9)", "entry");
            Row.padding({ left: 8, right: 8, top: 4, bottom: 4 });
            Row.backgroundColor('#FFF0F5');
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(57:11)", "entry");
            Image.width(16);
            Image.height(16);
            Image.objectFit(ImageFit.Contain);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('B站');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(61:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#FB7299');
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(70:9)", "entry");
            Row.padding({ left: 8, right: 8, top: 4, bottom: 4 });
            Row.backgroundColor('#F5F5F5');
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(71:11)", "entry");
            Image.width(16);
            Image.height(16);
            Image.objectFit(ImageFit.Contain);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('抖音');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(75:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#000000');
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(84:9)", "entry");
            Row.padding({ left: 8, right: 8, top: 4, bottom: 4 });
            Row.backgroundColor('#FFF5F0');
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(85:11)", "entry");
            Image.width(16);
            Image.height(16);
            Image.objectFit(ImageFit.Contain);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('快手');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(89:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#FF6B35');
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        // 平台标签
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 链接输入框
            TextInput.create({ placeholder: '粘贴博主主页链接' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(101:7)", "entry");
            // 链接输入框
            TextInput.width('100%');
            // 链接输入框
            TextInput.height(48);
            // 链接输入框
            TextInput.backgroundColor('#F5F5F5');
            // 链接输入框
            TextInput.borderRadius(8);
            // 链接输入框
            TextInput.padding({ left: 12, right: 12 });
            // 链接输入框
            TextInput.fontSize(14);
            // 链接输入框
            TextInput.placeholderColor('#999999');
            // 链接输入框
            TextInput.onChange((value: string) => {
                this.rawLinkInput = value; // 记录完整原始输入（抖音保留全文）
                const extractedUrl = this.extractUrl(value);
                if (extractedUrl) {
                    // 提取到纯净 URL → 替换整个输入内容为 URL
                    this.linkUrl = extractedUrl;
                }
                else {
                    // 没提取到 URL → 保留原始输入（可能是纯链接）
                    this.linkUrl = value;
                }
                this.isB23Link = this.linkUrl.includes('b23.tv');
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // b23.tv 短链提示
            if (this.isB23Link) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/Index.ets(124:9)", "entry");
                        Row.margin({ top: 8 });
                        Row.padding({ left: 8, right: 8, top: 6, bottom: 6 });
                        Row.backgroundColor('#F0F5FF');
                        Row.borderRadius(6);
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('ℹ ');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(125:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#0A59F7');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('检测到 B站短链接（b23.tv），系统将自动解析并获取博主信息。');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(126:11)", "entry");
                        Text.fontSize(12);
                        Text.lineHeight(18);
                        Text.fontColor('#0A59F7');
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('直接点击「确认解析」即可，头像获取可能需要稍等片刻。');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(135:9)", "entry");
                        Text.fontSize(11);
                        Text.lineHeight(16);
                        Text.fontColor('#999999');
                        Text.margin({ top: 4, left: 8, right: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            // 博主名称输入框
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 博主名称输入框
            TextInput.create({ placeholder: '输入博主名称（必填）' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(141:7)", "entry");
            // 博主名称输入框
            TextInput.width('100%');
            // 博主名称输入框
            TextInput.height(48);
            // 博主名称输入框
            TextInput.backgroundColor('#F5F5F5');
            // 博主名称输入框
            TextInput.borderRadius(8);
            // 博主名称输入框
            TextInput.padding({ left: 12, right: 12 });
            // 博主名称输入框
            TextInput.fontSize(14);
            // 博主名称输入框
            TextInput.placeholderColor('#999999');
            // 博主名称输入框
            TextInput.margin({ top: 12, bottom: 20 });
            // 博主名称输入框
            TextInput.onChange((value: string) => {
                this.creatorName = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 博主 ID 号输入框（可选）
            TextInput.create({ placeholder: '输入博主ID号（可选）' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(155:7)", "entry");
            // 博主 ID 号输入框（可选）
            TextInput.width('100%');
            // 博主 ID 号输入框（可选）
            TextInput.height(48);
            // 博主 ID 号输入框（可选）
            TextInput.backgroundColor('#F5F5F5');
            // 博主 ID 号输入框（可选）
            TextInput.borderRadius(8);
            // 博主 ID 号输入框（可选）
            TextInput.padding({ left: 12, right: 12 });
            // 博主 ID 号输入框（可选）
            TextInput.fontSize(14);
            // 博主 ID 号输入框（可选）
            TextInput.placeholderColor('#999999');
            // 博主 ID 号输入框（可选）
            TextInput.margin({ top: 0, bottom: 20 });
            // 博主 ID 号输入框（可选）
            TextInput.onChange((value: string) => {
                this.creatorId = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 按钮区域
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(169:7)", "entry");
            // 按钮区域
            Row.width('100%');
            // 按钮区域
            Row.justifyContent(FlexAlign.Center);
            // 按钮区域
            Row.margin({ bottom: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(170:9)", "entry");
            Button.width(120);
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor('#666666');
            Button.backgroundColor('#F5F5F5');
            Button.borderRadius(22);
            Button.onClick(() => {
                if (this.onCancel) {
                    this.onCancel();
                }
                this.controller?.close();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('确认解析');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(184:9)", "entry");
            Button.width(120);
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor('#0A59F7');
            Button.borderRadius(22);
            Button.onClick(() => {
                // 兜底：从当前输入中提取纯净 URL（应对 onChange 未能及时处理的边界情况）
                const finalUrl = this.extractUrl(this.linkUrl) ?? this.linkUrl.trim();
                if (!finalUrl) {
                    promptAction.showToast({
                        message: '请输入博主主页链接',
                        duration: 1500,
                        bottom: 100
                    });
                    return;
                }
                if (!this.creatorName || this.creatorName.trim() === '') {
                    promptAction.showToast({
                        message: '请输入博主名称',
                        duration: 1500,
                        bottom: 100
                    });
                    return;
                }
                const platform = this.detectPlatform(finalUrl);
                if (!platform) {
                    promptAction.showToast({
                        message: '暂不支持此平台链接，请检查后重试',
                        duration: 2000,
                        bottom: 100
                    });
                    return;
                }
                if (this.onConfirm) {
                    // 抖音：传完整原始文本保留全部内容；其他平台传提取后的纯净 URL
                    const confirmUrl = (platform === 'douyin' && this.rawLinkInput) ? this.rawLinkInput : finalUrl;
                    const creatorIdTrimmed = this.creatorId.trim();
                    this.onConfirm(confirmUrl, this.creatorName.trim(), creatorIdTrimmed || undefined);
                }
                this.controller?.close();
            });
        }, Button);
        Button.pop();
        // 按钮区域
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Example extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__isParsed = new ObservedPropertySimplePU(AppStorage.get<boolean>(STORAGE_KEYS.PARSED) || false, this, "isParsed");
        this.__biliCount = new ObservedPropertySimplePU(0, this, "biliCount");
        this.__douyinCount = new ObservedPropertySimplePU(0, this, "douyinCount");
        this.__kuaishouCount = new ObservedPropertySimplePU(0, this, "kuaishouCount");
        this.__isCheckingPermission = new ObservedPropertySimplePU(true, this, "isCheckingPermission");
        this.__permissionDenied = new ObservedPropertySimplePU(false, this, "permissionDenied");
        this.__isCheckingPrivacy = new ObservedPropertySimplePU(true, this, "isCheckingPrivacy");
        this.__isShowSheet = new ObservedPropertySimplePU(false, this, "isShowSheet");
        this.__isShowAgreement = new ObservedPropertySimplePU(false, this, "isShowAgreement");
        this.__isShowPrivacy = new ObservedPropertySimplePU(false, this, "isShowPrivacy");
        this.PERMISSION_NAME = 'ohos.permission.GET_BUNDLE_INFO';
        this.dialogController = null;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Example_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.isParsed !== undefined) {
            this.isParsed = params.isParsed;
        }
        if (params.biliCount !== undefined) {
            this.biliCount = params.biliCount;
        }
        if (params.douyinCount !== undefined) {
            this.douyinCount = params.douyinCount;
        }
        if (params.kuaishouCount !== undefined) {
            this.kuaishouCount = params.kuaishouCount;
        }
        if (params.isCheckingPermission !== undefined) {
            this.isCheckingPermission = params.isCheckingPermission;
        }
        if (params.permissionDenied !== undefined) {
            this.permissionDenied = params.permissionDenied;
        }
        if (params.isCheckingPrivacy !== undefined) {
            this.isCheckingPrivacy = params.isCheckingPrivacy;
        }
        if (params.isShowSheet !== undefined) {
            this.isShowSheet = params.isShowSheet;
        }
        if (params.isShowAgreement !== undefined) {
            this.isShowAgreement = params.isShowAgreement;
        }
        if (params.isShowPrivacy !== undefined) {
            this.isShowPrivacy = params.isShowPrivacy;
        }
        if (params.PERMISSION_NAME !== undefined) {
            this.PERMISSION_NAME = params.PERMISSION_NAME;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params: Example_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__isParsed.purgeDependencyOnElmtId(rmElmtId);
        this.__biliCount.purgeDependencyOnElmtId(rmElmtId);
        this.__douyinCount.purgeDependencyOnElmtId(rmElmtId);
        this.__kuaishouCount.purgeDependencyOnElmtId(rmElmtId);
        this.__isCheckingPermission.purgeDependencyOnElmtId(rmElmtId);
        this.__permissionDenied.purgeDependencyOnElmtId(rmElmtId);
        this.__isCheckingPrivacy.purgeDependencyOnElmtId(rmElmtId);
        this.__isShowSheet.purgeDependencyOnElmtId(rmElmtId);
        this.__isShowAgreement.purgeDependencyOnElmtId(rmElmtId);
        this.__isShowPrivacy.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        this.__isParsed.aboutToBeDeleted();
        this.__biliCount.aboutToBeDeleted();
        this.__douyinCount.aboutToBeDeleted();
        this.__kuaishouCount.aboutToBeDeleted();
        this.__isCheckingPermission.aboutToBeDeleted();
        this.__permissionDenied.aboutToBeDeleted();
        this.__isCheckingPrivacy.aboutToBeDeleted();
        this.__isShowSheet.aboutToBeDeleted();
        this.__isShowAgreement.aboutToBeDeleted();
        this.__isShowPrivacy.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    private __isParsed: ObservedPropertySimplePU<boolean>;
    get isParsed() {
        return this.__isParsed.get();
    }
    set isParsed(newValue: boolean) {
        this.__isParsed.set(newValue);
    }
    private __biliCount: ObservedPropertySimplePU<number>;
    get biliCount() {
        return this.__biliCount.get();
    }
    set biliCount(newValue: number) {
        this.__biliCount.set(newValue);
    }
    private __douyinCount: ObservedPropertySimplePU<number>;
    get douyinCount() {
        return this.__douyinCount.get();
    }
    set douyinCount(newValue: number) {
        this.__douyinCount.set(newValue);
    }
    private __kuaishouCount: ObservedPropertySimplePU<number>;
    get kuaishouCount() {
        return this.__kuaishouCount.get();
    }
    set kuaishouCount(newValue: number) {
        this.__kuaishouCount.set(newValue);
    }
    // 启动权限检查状态
    private __isCheckingPermission: ObservedPropertySimplePU<boolean>;
    get isCheckingPermission() {
        return this.__isCheckingPermission.get();
    }
    set isCheckingPermission(newValue: boolean) {
        this.__isCheckingPermission.set(newValue);
    }
    private __permissionDenied: ObservedPropertySimplePU<boolean>;
    get permissionDenied() {
        return this.__permissionDenied.get();
    }
    set permissionDenied(newValue: boolean) {
        this.__permissionDenied.set(newValue);
    }
    // 隐私协议检查状态
    private __isCheckingPrivacy: ObservedPropertySimplePU<boolean>;
    get isCheckingPrivacy() {
        return this.__isCheckingPrivacy.get();
    }
    set isCheckingPrivacy(newValue: boolean) {
        this.__isCheckingPrivacy.set(newValue);
    }
    private __isShowSheet: ObservedPropertySimplePU<boolean>;
    get isShowSheet() {
        return this.__isShowSheet.get();
    }
    set isShowSheet(newValue: boolean) {
        this.__isShowSheet.set(newValue);
    }
    private __isShowAgreement: ObservedPropertySimplePU<boolean>;
    get isShowAgreement() {
        return this.__isShowAgreement.get();
    }
    set isShowAgreement(newValue: boolean) {
        this.__isShowAgreement.set(newValue);
    }
    private __isShowPrivacy: ObservedPropertySimplePU<boolean>;
    get isShowPrivacy() {
        return this.__isShowPrivacy.get();
    }
    set isShowPrivacy(newValue: boolean) {
        this.__isShowPrivacy.set(newValue);
    }
    private readonly PERMISSION_NAME: Permissions;
    // 弹窗控制器（初始为 null，只在打开时创建）
    private dialogController: CustomDialogController | null;
    aboutToAppear(): void {
        this.refreshCounts();
        // 先检查隐私协议，同意后再检查权限
        this.checkPrivacyAgreement();
    }
    onPageShow(): void {
        this.refreshCounts();
    }
    aboutToDisappear(): void {
        this.dialogController?.close();
        this.dialogController = null;
    }
    refreshCounts(): void {
        this.isParsed = AppStorage.get<boolean>(STORAGE_KEYS.PARSED) || false;
        if (this.isParsed) {
            this.biliCount = getCreatorCount('bilibili');
            this.douyinCount = getCreatorCount('douyin');
            this.kuaishouCount = getCreatorCount('kuaishou');
        }
    }
    // ===== 启动权限检查 =====
    // 在 aboutToAppear 调用，检查 OHOS.permission.GET_BUNDLE_INFO
    // 不允许 → 弹窗说明 → 点击退出 → terminateSelf
    // 允许后 → AppStorage 标记，后续启动不再询问
    private async checkStartupPermission(): Promise<void> {
        // 检查是否已标记为已授权
        const alreadyGranted = AppStorage.get<boolean>('startup_permission_granted') || false;
        if (alreadyGranted) {
            this.isCheckingPermission = false;
            return;
        }
        const atManager = abilityAccessCtrl.createAtManager();
        let tokenId: number = 0;
        try {
            const bundleInfo = bundleManager.getBundleInfoForSelfSync(bundleManager.BundleFlag.GET_BUNDLE_INFO_WITH_APPLICATION);
            tokenId = bundleInfo.appInfo.accessTokenId;
        }
        catch (e) {
            console.error('[Permission] 获取 tokenId 失败:', JSON.stringify(e));
            this.isCheckingPermission = false;
            return;
        }
        // 检查是否已授予
        const grantStatus = atManager.checkAccessTokenSync(tokenId, this.PERMISSION_NAME);
        if (grantStatus === abilityAccessCtrl.GrantStatus.PERMISSION_GRANTED) {
            AppStorage.set('startup_permission_granted', true);
            this.permissionDenied = false;
            this.isCheckingPermission = false;
            return;
        }
        // 未授权 → 请求用户授权
        try {
            const ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
            const result = await atManager.requestPermissionsFromUser(ctx, [this.PERMISSION_NAME]);
            if (result.authResults[0] === 0) {
                // 用户允许
                AppStorage.set('startup_permission_granted', true);
                this.permissionDenied = false;
            }
            else {
                // 用户拒绝
                this.permissionDenied = true;
            }
        }
        catch (e) {
            const err = e as BusinessError;
            console.error('[Permission] 请求权限异常:', err.code, err.message);
            this.permissionDenied = true;
        }
        this.isCheckingPermission = false;
    }
    // ===== 隐私协议同意检查 =====
    // 在 aboutToAppear 中首先调用，确保用户同意隐私协议后才继续使用
    private checkPrivacyAgreement(): void {
        const agreed = AppStorage.get<boolean>(PREFS_KEYS.PRIVACY_AGREED) || false;
        if (agreed) {
            this.isCheckingPrivacy = false;
            // 已同意过隐私协议，继续检查权限
            this.checkStartupPermission();
            return;
        }
        // 未同意 → 先隐藏 loading 遮罩层，再显示隐私协议底部面板
        this.isCheckingPermission = false;
        this.isShowSheet = true;
    }
    // 处理链接解析 → 逐个添加博主（头像由后台自动获取）
    async handleParseLink(url: string, name: string, creatorId?: string): Promise<void> {
        console.info('开始解析链接:', url, '博主名称:', name, '博主ID:', creatorId ?? '(未填)');
        // 先解析短链，获取深链（如 snssdk1128://user/xxx）
        const resolved = await resolveLink(url);
        const deepLink = resolved?.deepLink;
        const realUrl = resolved?.realUrl;
        const uid = resolved?.uid;
        const result = parseAndAddCreator(url, name, deepLink, realUrl, uid, creatorId);
        if (!result) {
            promptAction.showToast({
                message: '暂不支持此平台链接，请检查后重试',
                duration: 1500,
                bottom: 100
            });
            return;
        }
        // 更新状态
        this.isParsed = true;
        this.refreshCounts();
        // 反馈：显示博主名称
        if (result.isNew) {
            promptAction.showToast({
                message: `已添加博主「${result.name}」到${getPlatformChinese(result.platform)}收藏`,
                duration: 2000,
                bottom: 100
            });
        }
        else {
            promptAction.showToast({
                message: `博主「${result.name}」已在${getPlatformChinese(result.platform)}收藏中`,
                duration: 2000,
                bottom: 100
            });
        }
        // 注意：解析后不跳转，用户稍后可在平台列表中手动点击跳转
    }
    // 打开解析弹窗
    openParseDialog(): void {
        // 先关闭已有弹窗，确保资源完全释放
        this.dialogController?.close();
        // 创建新控制器（CustomDialog 参数不支持动态刷新，每次需重建）
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new ParseLinkDialog(this, {
                    onConfirm: (url: string, name: string, creatorId?: string) => {
                        this.handleParseLink(url, name, creatorId);
                    },
                    onCancel: () => {
                        console.info('用户取消解析');
                    }
                }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 405, col: 16 });
                jsDialog.setController(
                // 创建新控制器（CustomDialog 参数不支持动态刷新，每次需重建）
                this.dialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        onConfirm: (url: string, name: string, creatorId?: string) => {
                            this.handleParseLink(url, name, creatorId);
                        },
                        onCancel: () => {
                            console.info('用户取消解析');
                        }
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            autoCancel: true,
            customStyle: true,
            alignment: DialogAlignment.Center,
            maskColor: 'rgba(0, 0, 0, 0.5)'
        }, this);
        this.dialogController.open();
    }
    buildTabBar(index: number, title: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(422:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (0 == index) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentIndex == 0 ? { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" } : { "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/Index.ets(424:9)", "entry");
                        Image.width(24);
                        Image.height(24);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(title);
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(426:9)", "entry");
                        Text.fontSize(12);
                        Text.margin({ top: 4 });
                        Text.fontColor(this.currentIndex == 0 ? "#0A59F7" : "#000000");
                    }, Text);
                    Text.pop();
                });
            }
            else if (1 == index) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.currentIndex == 1 ? { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" } : { "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/Index.ets(431:9)", "entry");
                        Image.width(24);
                        Image.height(24);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(title);
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(433:9)", "entry");
                        Text.fontSize(12);
                        Text.margin({ top: 4 });
                        Text.fontColor(this.currentIndex == 1 ? "#0A59F7" : "#000000");
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    // ===== 隐私协议底部面板内容 =====
    privacySheet(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(447:5)", "entry");
            Column.width('100%');
            Column.justifyContent(FlexAlign.End);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 白色卡片区域
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(449:7)", "entry");
            // 白色卡片区域
            Column.width('100%');
            // 白色卡片区域
            Column.padding({ left: 24, right: 24 });
            // 白色卡片区域
            Column.backgroundColor(Color.White);
            // 白色卡片区域
            Column.borderRadius({ topLeft: 20, topRight: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 拖拽指示条
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(451:9)", "entry");
            // 拖拽指示条
            Row.width(36);
            // 拖拽指示条
            Row.height(4);
            // 拖拽指示条
            Row.borderRadius(2);
            // 拖拽指示条
            Row.backgroundColor('#D9D9D9');
            // 拖拽指示条
            Row.margin({ top: 8, bottom: 4 });
        }, Row);
        // 拖拽指示条
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题
            Text.create('用户协议与隐私政策');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(457:9)", "entry");
            // 标题
            Text.fontSize(18);
            // 标题
            Text.fontWeight(FontWeight.Medium);
            // 标题
            Text.fontColor('#1A1A1A');
            // 标题
            Text.lineHeight(24);
            // 标题
            Text.margin({ top: 12, bottom: 16 });
        }, Text);
        // 标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Index.ets(464:9)", "entry");
            // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
            Text.textAlign(TextAlign.JUSTIFY);
            // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
            Text.width('100%');
            // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
            Text.margin({ bottom: 24 });
            // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
            Text.bindContentCover({ value: this.isShowAgreement, changeEvent: newValue => { this.isShowAgreement = newValue; } }, { builder: () => {
                    this.agreementContent.call(this);
                } });
            // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
            Text.bindContentCover({ value: this.isShowPrivacy, changeEvent: newValue => { this.isShowPrivacy = newValue; } }, { builder: () => {
                    this.privacyContent.call(this);
                } });
        }, Text);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('在您使用本应用之前，请您仔细阅读并同意');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(465:11)", "entry");
            Span.fontSize(14);
            Span.fontColor('#666666');
            Span.lineHeight(20);
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('《用户协议》');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(467:11)", "entry");
            Span.fontSize(14);
            Span.fontColor('#0A59F7');
            Span.lineHeight(20);
            Span.onClick(() => {
                this.isShowAgreement = true;
            });
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create(' 和 ');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(472:11)", "entry");
            Span.fontSize(14);
            Span.fontColor('#666666');
            Span.lineHeight(20);
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('《隐私政策》');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(474:11)", "entry");
            Span.fontSize(14);
            Span.fontColor('#0A59F7');
            Span.lineHeight(20);
            Span.onClick(() => {
                this.isShowPrivacy = true;
            });
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('。');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(479:11)", "entry");
            Span.fontSize(14);
            Span.fontColor('#666666');
            Span.lineHeight(20);
        }, Span);
        // 说明文字（《用户协议》《隐私政策》可点击跳转详情）
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 按钮区域
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(490:9)", "entry");
            // 按钮区域
            Row.width('100%');
            // 按钮区域
            Row.justifyContent(FlexAlign.Center);
            // 按钮区域
            Row.margin({ bottom: 32 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('不同意并退出');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(491:11)", "entry");
            Button.width(140);
            Button.height(44);
            Button.fontSize(15);
            Button.fontColor('#666666');
            Button.backgroundColor('#F5F5F5');
            Button.borderRadius(22);
            Button.onClick(() => {
                this.onDisagree();
                this.isShowSheet = false;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('同意并继续');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(500:11)", "entry");
            Button.width(140);
            Button.height(44);
            Button.fontSize(15);
            Button.fontColor(Color.White);
            Button.backgroundColor('#0A59F7');
            Button.borderRadius(22);
            Button.onClick(() => {
                this.onAgree();
                this.isShowSheet = false;
            });
        }, Button);
        Button.pop();
        // 按钮区域
        Row.pop();
        // 白色卡片区域
        Column.pop();
        Column.pop();
    }
    // ===== 用户协议详情覆盖层 =====
    agreementContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(525:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(526:7)", "entry");
            Row.alignItems(VerticalAlign.Center);
            Row.onClick(() => {
                this.isShowAgreement = false;
            });
            Row.padding({ left: 16, top: 12, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('‹');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(527:9)", "entry");
            Text.fontSize(22);
            Text.fontColor('#0A59F7');
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(529:9)", "entry");
            Blank.width(4);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返回');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(530:9)", "entry");
            Text.fontSize(15);
            Text.fontColor('#0A59F7');
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('用户协议');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(539:7)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#1A1A1A');
            Text.margin({ left: 16, bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(544:7)", "entry");
            Scroll.padding({ left: 16, right: 16 });
            Scroll.layoutWeight(1);
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('欢迎使用博主聚合收藏夹！\n\n一、服务条款的接受\n请您在使用本应用前仔细阅读本协议。您使用本应用即表示您已同意本协议的条款与条件。\n\n二、服务内容\n本应用提供博主链接收藏与管理功能，支持B站、抖音、快手等平台的博主信息管理。\n\n三、用户行为规范\n1. 用户不得利用本应用从事违法违规活动；\n2. 用户不得对本应用进行逆向工程、反编译等操作。\n\n四、知识产权\n本应用所展示的各平台Logo、商标等知识产权归各平台所有。\n\n五、免责声明\n本应用仅提供工具性质的服务，用户在使用过程中应遵守各平台的相关规定。\n\n六、协议变更\n本应用有权根据需要修改本协议，修改后的协议会通过应用内更新告知用户。\n\n七、联系我们\n如有任何问题，请通过应用内反馈功能联系我们。');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(545:9)", "entry");
            Text.fontSize(15);
            Text.fontColor('#444444');
            Text.lineHeight(24);
            Text.textAlign(TextAlign.Start);
            Text.width('100%');
        }, Text);
        Text.pop();
        Scroll.pop();
        Column.pop();
    }
    // ===== 隐私政策详情覆盖层 =====
    privacyContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(563:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(564:7)", "entry");
            Row.alignItems(VerticalAlign.Center);
            Row.onClick(() => {
                this.isShowPrivacy = false;
            });
            Row.padding({ left: 16, top: 12, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('‹');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(565:9)", "entry");
            Text.fontSize(22);
            Text.fontColor('#0A59F7');
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(567:9)", "entry");
            Blank.width(4);
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返回');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(568:9)", "entry");
            Text.fontSize(15);
            Text.fontColor('#0A59F7');
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('隐私政策');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(577:7)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#1A1A1A');
            Text.margin({ left: 16, bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(582:7)", "entry");
            Scroll.padding({ left: 16, right: 16 });
            Scroll.layoutWeight(1);
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('本应用尊重并保护所有使用服务用户的个人隐私权。为了给您提供更准确、更有个性化的服务，本应用会按照本隐私权政策的规定使用和披露您的个人信息。但本应用将以高度的勤勉、审慎义务对待这些信息。除本隐私权政策另有规定外，在未征得您事先许可的情况下，本应用不会将这些信息对外披露或向第三方提供。本应用会不时更新本隐私权政策。您在同意本应用服务使用协议之时，即视为您已经同意本隐私权政策全部内容。\n\n一、适用范围\n1. 在您使用本应用网络服务时，您根据本应用要求提供的个人数据；\n2. 您在使用本应用服务过程中产生的数据（如收藏的博主列表等）。\n\n二、信息使用\n1. 本应用不会向任何无关第三方提供、出售、出租、分享或交易您的个人信息；\n2. 本应用亦不允许任何第三方以任何手段收集、编辑、出售或传播您的个人信息。\n\n三、信息披露\n在如下情况下，本应用将依据您的个人意愿或法律的规定全部或部分披露您的个人信息：\n1. 经您事先同意，向第三方披露；\n2. 根据法律的有关规定，或者行政或司法机构的要求，向第三方或者行政、司法机构披露。\n\n四、信息存储与保护\n1. 本应用收集的有关您的信息均存储在您的设备本地，不会上传至任何服务器；\n2. 我们采用业界标准的加密措施保护您数据的安全。');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(583:9)", "entry");
            Text.fontSize(15);
            Text.fontColor('#444444');
            Text.lineHeight(24);
            Text.textAlign(TextAlign.Start);
            Text.width('100%');
        }, Text);
        Text.pop();
        Scroll.pop();
        Column.pop();
    }
    // ===== 用户协议/隐私政策同意/不同意回调 =====
    private onAgree(): void {
        AppStorage.set(PREFS_KEYS.PRIVACY_AGREED, true);
        setBool(PREFS_KEYS.PRIVACY_AGREED, true);
        this.isCheckingPrivacy = false;
        this.isShowSheet = false; // 关闭 bindSheet 底部面板，避免与系统权限弹窗冲突
        // 延迟一帧检查权限，确保 bindSheet 已关闭
        setTimeout(() => {
            this.checkStartupPermission();
        }, 300);
    }
    private onDisagree(): void {
        try {
            const ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
            ctx.terminateSelf();
        }
        catch (e) {
            console.error('[Privacy] 退出应用失败:', JSON.stringify(e));
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(620:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.bindSheet({ value: this.isShowSheet, changeEvent: newValue => { this.isShowSheet = newValue; } }, this.privacySheet.bind(this), {
                height: SheetSize.FIT_CONTENT,
                preferType: SheetType.BOTTOM
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // ===== 主内容（Tabs + 浮窗按钮） =====
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(622:7)", "entry");
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Stack.create();
                    Stack.debugLine("entry/src/main/ets/pages/Index.ets(624:11)", "entry");
                }, Stack);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(625:13)", "entry");
                    Column.width('100%');
                    Column.height('100%');
                    Column.padding({ top: 20, left: 16, right: 16 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // ===== 顶部固定区域：标题和平台介绍 =====
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(627:15)", "entry");
                    // ===== 顶部固定区域：标题和平台介绍 =====
                    Row.margin({ top: 8, bottom: 24 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(628:17)", "entry");
                    Column.height(40);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create("博主聚合收藏夹");
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(629:19)", "entry");
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Bold);
                    Text.margin({ bottom: 4 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(634:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('支持解析');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(635:21)", "entry");
                    Text.fontSize(15);
                    Text.fontColor('#666666');
                    Text.margin({ right: 12 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 8 });
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(640:21)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(641:23)", "entry");
                    Image.width(20);
                    Image.height(20);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('B站');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(644:23)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#FB7299');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(648:23)", "entry");
                    Image.width(20);
                    Image.height(20);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('抖音');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(651:23)", "entry");
                    Text.fontSize(14);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(654:23)", "entry");
                    Image.width(20);
                    Image.height(20);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('快手');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(657:23)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#FF6B35');
                }, Text);
                Text.pop();
                Row.pop();
                Row.pop();
                Column.pop();
                // ===== 顶部固定区域：标题和平台介绍 =====
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // B站卡片
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(668:15)", "entry");
                    // B站卡片
                    Row.width('100%');
                    // B站卡片
                    Row.height(64);
                    // B站卡片
                    Row.backgroundColor(Color.White);
                    // B站卡片
                    Row.borderRadius(12);
                    // B站卡片
                    Row.padding({ left: 16, right: 16 });
                    // B站卡片
                    Row.shadow({ radius: 4, color: '#0D000000', offsetY: 2 });
                    // B站卡片
                    Row.alignItems(VerticalAlign.Center);
                    // B站卡片
                    Row.onClick(() => {
                        router.pushUrl({ url: 'pages/BilibiliPage' });
                    });
                    // B站卡片
                    Row.margin({ bottom: 12 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(669:17)", "entry");
                    Image.width(36);
                    Image.height(36);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 2 });
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(672:17)", "entry");
                    Column.alignItems(HorizontalAlign.Start);
                    Column.layoutWeight(1);
                    Column.margin({ left: 12 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 8 });
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(673:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('B站收藏');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(674:21)", "entry");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.biliCount > 0) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${this.biliCount}`);
                                Text.debugLine("entry/src/main/ets/pages/Index.ets(678:23)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Color.White);
                                Text.backgroundColor('#FB7299');
                                Text.borderRadius(8);
                                Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                            }, Text);
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('点击查看B站博主收藏列表');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(686:19)", "entry");
                    Text.fontSize(13);
                    Text.fontColor('#999999');
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('›');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(692:17)", "entry");
                    Text.fontSize(20);
                    Text.fontColor('#CCCCCC');
                }, Text);
                Text.pop();
                // B站卡片
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 抖音卡片
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(707:15)", "entry");
                    // 抖音卡片
                    Row.width('100%');
                    // 抖音卡片
                    Row.height(64);
                    // 抖音卡片
                    Row.backgroundColor(Color.White);
                    // 抖音卡片
                    Row.borderRadius(12);
                    // 抖音卡片
                    Row.padding({ left: 16, right: 16 });
                    // 抖音卡片
                    Row.shadow({ radius: 4, color: '#0D000000', offsetY: 2 });
                    // 抖音卡片
                    Row.alignItems(VerticalAlign.Center);
                    // 抖音卡片
                    Row.onClick(() => {
                        router.pushUrl({ url: 'pages/DouyinPage' });
                    });
                    // 抖音卡片
                    Row.margin({ bottom: 12 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(708:17)", "entry");
                    Image.width(36);
                    Image.height(36);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 2 });
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(711:17)", "entry");
                    Column.alignItems(HorizontalAlign.Start);
                    Column.layoutWeight(1);
                    Column.margin({ left: 12 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 8 });
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(712:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('抖音收藏');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(713:21)", "entry");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.douyinCount > 0) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${this.douyinCount}`);
                                Text.debugLine("entry/src/main/ets/pages/Index.ets(717:23)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Color.White);
                                Text.backgroundColor('#000000');
                                Text.borderRadius(8);
                                Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                            }, Text);
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('点击查看抖音博主收藏列表');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(725:19)", "entry");
                    Text.fontSize(13);
                    Text.fontColor('#999999');
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('›');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(731:17)", "entry");
                    Text.fontSize(20);
                    Text.fontColor('#CCCCCC');
                }, Text);
                Text.pop();
                // 抖音卡片
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 快手卡片
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(746:15)", "entry");
                    // 快手卡片
                    Row.width('100%');
                    // 快手卡片
                    Row.height(64);
                    // 快手卡片
                    Row.backgroundColor(Color.White);
                    // 快手卡片
                    Row.borderRadius(12);
                    // 快手卡片
                    Row.padding({ left: 16, right: 16 });
                    // 快手卡片
                    Row.shadow({ radius: 4, color: '#0D000000', offsetY: 2 });
                    // 快手卡片
                    Row.alignItems(VerticalAlign.Center);
                    // 快手卡片
                    Row.onClick(() => {
                        router.pushUrl({ url: 'pages/KuaishouPage' });
                    });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(747:17)", "entry");
                    Image.width(36);
                    Image.height(36);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 2 });
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(750:17)", "entry");
                    Column.alignItems(HorizontalAlign.Start);
                    Column.layoutWeight(1);
                    Column.margin({ left: 12 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 8 });
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(751:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('快手收藏');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(752:21)", "entry");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.kuaishouCount > 0) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${this.kuaishouCount}`);
                                Text.debugLine("entry/src/main/ets/pages/Index.ets(756:23)", "entry");
                                Text.fontSize(12);
                                Text.fontColor(Color.White);
                                Text.backgroundColor('#FF6B35');
                                Text.borderRadius(8);
                                Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                            }, Text);
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                        });
                    }
                }, If);
                If.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('点击查看快手博主收藏列表');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(764:19)", "entry");
                    Text.fontSize(13);
                    Text.fontColor('#999999');
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('›');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(770:17)", "entry");
                    Text.fontSize(20);
                    Text.fontColor('#CCCCCC');
                }, Text);
                Text.pop();
                // 快手卡片
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/Index.ets(783:15)", "entry");
                    Blank.height(20);
                }, Blank);
                Blank.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 浮动添加按钮
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(790:13)", "entry");
                    // 浮动添加按钮
                    Row.width('100%');
                    // 浮动添加按钮
                    Row.zIndex(999);
                    // 浮动添加按钮
                    Row.padding({ right: 20 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/Index.ets(791:15)", "entry");
                }, Blank);
                Blank.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithChild();
                    Button.debugLine("entry/src/main/ets/pages/Index.ets(792:15)", "entry");
                    Button.width(56);
                    Button.height(56);
                    Button.backgroundColor('#0A59F7');
                    Button.borderRadius(28);
                    Button.shadow({ radius: 8, color: '#200A59F7', offsetY: 2 });
                    Button.onClick(() => {
                        this.openParseDialog();
                    });
                }, Button);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('+');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(793:17)", "entry");
                    Text.fontSize(24);
                    Text.fontWeight(FontWeight.Bold);
                    Text.fontColor(Color.White);
                }, Text);
                Text.pop();
                Button.pop();
                // 浮动添加按钮
                Row.pop();
                Stack.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.buildTabBar.call(this, 0, "首页");
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(623:9)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(814:11)", "entry");
                    Column.width('100%');
                    Column.height('100%');
                    Column.padding({ top: 20, left: 16 });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create("华为账号登录");
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(815:13)", "entry");
                    Text.fontWeight(FontWeight.Bold);
                }, Text);
                Text.pop();
                Column.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.buildTabBar.call(this, 1, "我的");
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(813:9)", "entry");
        }, TabContent);
        TabContent.pop();
        // ===== 主内容（Tabs + 浮窗按钮） =====
        Tabs.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // ===== 权限检查覆盖层 =====
            if (this.isCheckingPermission || this.permissionDenied) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(827:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.backgroundColor('#FFFFFF');
                        Column.justifyContent(FlexAlign.Center);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isCheckingPermission) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/Index.ets(829:13)", "entry");
                                    LoadingProgress.width(48);
                                    LoadingProgress.height(48);
                                    LoadingProgress.color('#0A59F7');
                                }, LoadingProgress);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('检查权限中...');
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(832:13)", "entry");
                                    Text.fontSize(16);
                                    Text.fontColor('#666666');
                                    Text.margin({ top: 12 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('🔒');
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(837:13)", "entry");
                                    Text.fontSize(48);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('需要「读取应用列表」权限');
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(839:13)", "entry");
                                    Text.fontSize(20);
                                    Text.fontWeight(FontWeight.Bold);
                                    Text.fontColor('#333333');
                                    Text.margin({ top: 20 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('用于检测B站/抖音/快手等应用是否已安装，\n以实现一键直达跳转功能');
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(843:13)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor('#666666');
                                    Text.textAlign(TextAlign.Center);
                                    Text.lineHeight(22);
                                    Text.margin({ top: 12, bottom: 32 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('退出应用');
                                    Button.debugLine("entry/src/main/ets/pages/Index.ets(848:13)", "entry");
                                    Button.width(200);
                                    Button.height(44);
                                    Button.fontSize(16);
                                    Button.fontColor(Color.White);
                                    Button.backgroundColor('#FF5252');
                                    Button.borderRadius(22);
                                    Button.onClick(() => {
                                        const ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
                                        ctx.terminateSelf();
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Example";
    }
}
registerNamedRoute(() => new Example(undefined, {}), "", { bundleName: "com.example.upsavelist", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
