import { setString, setBool } from "@normalized:N&&&entry/src/main/ets/models/PreferencesHelper&";
import { fetchAvatarFromUrl } from "@normalized:N&&&entry/src/main/ets/utils/AvatarFetcher&";
// ===== 博主数据接口（含头像） =====
export interface CreatorInfo {
    id: string;
    name: string;
    description: string;
    platform: string;
    followers: string;
    link: string;
    deepLink?: string; // 解析后的 scheme 深链，可直接 startAbility
    realUrl?: string; // 解析后的真实 HTTPS 主页链接
    uid?: string; // 平台用户标识（UID / sec_uid / user_id）
    creatorId?: string; // 用户手动输入的博主 ID 号（如抖音号）
    avatarColor: string; // 用于生成首字母彩色头像（无真实头像时兜底）
    avatar?: string; // 博主真实头像链接（可选，为空时用 avatarColor 兜底）
}
// ===== 解析结果接口 =====
export interface ParseResult {
    platform: string;
    name: string;
    isNew: boolean; // 是否新增（false 表示链接已存在）
}
// ===== 存储键名 =====
export interface StorageKeys {
    BILIBILI: string;
    DOUYIN: string;
    KUAISHOU: string;
    PARSED: string;
    DEEP_LINK: string;
}
export const STORAGE_KEYS: StorageKeys = {
    BILIBILI: 'bilibili_creators',
    DOUYIN: 'douyin_creators',
    KUAISHOU: 'kuaishou_creators',
    PARSED: 'creators_parsed_flag',
    DEEP_LINK: 'deep_link_allowed'
};
// ===== 平台标识工具 =====
export function getPlatformLogo(platform: string): Resource {
    if (platform === 'bilibili') {
        return { "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" };
    }
    else if (platform === 'douyin') {
        return { "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" };
    }
    else {
        return { "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.upsavelist", "moduleName": "entry" };
    }
}
export function getPlatformChinese(platform: string): string {
    if (platform === 'bilibili')
        return 'B站';
    if (platform === 'douyin')
        return '抖音';
    if (platform === 'kuaishou')
        return '快手';
    return '';
}
// ===== 头像颜色生成（根据 id 哈希值） =====
const AVATAR_COLORS: string[] = [
    '#FB7299', '#0A59F7', '#FF6B35', '#7C4DFF',
    '#00BCD4', '#4CAF50', '#FF5722', '#E91E63',
    '#3F51B5', '#009688', '#795548', '#607D8B'
];
export function getAvatarColor(id: string): string {
    let hash = 0;
    for (let i = 0; i < id.length; i++) {
        hash = hash * 31 + id.charCodeAt(i);
    }
    return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}
// ===== 从 URL 检测平台 =====
export function detectPlatform(url: string): string {
    if (url.includes('bilibili.com') || url.includes('b23.tv')) {
        return 'bilibili';
    }
    else if (url.includes('douyin.com') || url.includes('iesdouyin.com')) {
        return 'douyin';
    }
    else if (url.includes('kuaishou.com') || url.includes('kuaishou.cn')) {
        return 'kuaishou';
    }
    return '';
}
// ===== 获取存储键 =====
function getStorageKey(platform: string): string {
    if (platform === 'bilibili')
        return STORAGE_KEYS.BILIBILI;
    if (platform === 'douyin')
        return STORAGE_KEYS.DOUYIN;
    return STORAGE_KEYS.KUAISHOU;
}
// ===== 核心：解析链接 → 添加一个博主到对应平台 =====
export function parseAndAddCreator(url: string, name: string, deepLink?: string, realUrl?: string, uid?: string, creatorId?: string): ParseResult | null {
    // 1. 检测平台
    const platform = detectPlatform(url);
    if (!platform)
        return null;
    // 2. 生成唯一 ID
    const urlHash = Math.abs(hashStr(url));
    const id = `${platform[0]}_${urlHash}`;
    // 3. 检查是否已存在（同链接不重复添加）
    const existing = getRawCreatorData(platform) || [];
    const alreadyExists = existing.some((c) => c.link === url);
    if (alreadyExists) {
        return { platform: platform, name: name, isNew: false } as ParseResult;
    }
    // 4. 构造新博主数据（头像先置空，后台异步获取）
    const creator: CreatorInfo = {
        id: id,
        name: name,
        description: '',
        platform: platform,
        followers: '',
        link: url,
        deepLink: deepLink,
        realUrl: realUrl,
        uid: uid,
        creatorId: creatorId,
        avatarColor: getAvatarColor(id),
        avatar: undefined
    };
    // 5. 追加写入 AppStorage（同步，用于 UI 即时响应）
    existing.push(creator);
    const key = getStorageKey(platform);
    AppStorage.setOrCreate(key, JSON.stringify(existing));
    AppStorage.setOrCreate(STORAGE_KEYS.PARSED, true);
    // 6. 持久化写入 Preferences（异步，用于进程重启后恢复）
    setString(key, JSON.stringify(existing));
    setBool(STORAGE_KEYS.PARSED, true);
    // 7. 后台异步获取博主头像（成功后会更新存储并触发 UI 刷新）
    fetchAndUpdateAvatar(platform, url, id, key);
    return { platform: platform, name: name, isNew: true } as ParseResult;
}
// ===== 简易字符串哈希 =====
function hashStr(s: string): number {
    let hash = 0;
    for (let i = 0; i < s.length; i++) {
        hash = hash * 31 + s.charCodeAt(i);
    }
    return hash;
}
// ===== 后台异步获取头像 =====
async function fetchAndUpdateAvatar(platform: string, url: string, creatorId: string, storageKey: string): Promise<void> {
    try {
        const avatarUrl = await fetchAvatarFromUrl(platform, url);
        if (avatarUrl) {
            updateCreatorAvatar(storageKey, creatorId, avatarUrl);
        }
        else if (platform === 'bilibili' && url.includes('b23.tv')) {
            // b23.tv 短链接：HTTP 解析失败属预期行为（跳转 B站 App）
            // 头像保留为彩色首字母兜底，不视为错误
            console.info('[CreatorModel] b23.tv short link avatar unavailable (expected):', url);
        }
    }
    catch (e) {
        console.error('[CreatorModel] fetch avatar error:', JSON.stringify(e));
    }
}
// ===== 更新已存储博主的头像地址 =====
function updateCreatorAvatar(storageKey: string, creatorId: string, avatarUrl: string): void {
    const raw: string | undefined = AppStorage.get<string>(storageKey);
    if (!raw)
        return;
    try {
        const list: CreatorInfo[] = JSON.parse(raw);
        const index = list.findIndex((c) => c.id === creatorId);
        if (index === -1)
            return;
        list[index].avatar = avatarUrl;
        AppStorage.setOrCreate(storageKey, JSON.stringify(list)); // 触发 UI 刷新
        setString(storageKey, JSON.stringify(list)); // 持久化更新
    }
    catch (e) {
        console.error('[CreatorModel] update avatar error:', e);
    }
}
// ===== 根据索引删除博主 =====
export function deleteCreatorByIndex(platform: string, index: number): void {
    const key = getStorageKey(platform);
    const raw: string | undefined = AppStorage.get<string>(key);
    if (!raw)
        return;
    try {
        const list: CreatorInfo[] = JSON.parse(raw);
        if (index < 0 || index >= list.length)
            return;
        list.splice(index, 1);
        const updated = JSON.stringify(list);
        // 更新 AppStorage → 触发 @StorageProp UI 刷新
        AppStorage.setOrCreate(key, updated);
        // 持久化到 Preferences
        setString(key, updated);
    }
    catch (e) {
        console.error('[CreatorModel] delete error:', e);
    }
}
// ===== 读取原始数据 =====
export function getRawCreatorData(platform: string): CreatorInfo[] | null {
    const key = getStorageKey(platform);
    const raw: string | undefined = AppStorage.get<string>(key);
    if (raw !== undefined && raw !== null) {
        try {
            return JSON.parse(raw) as CreatorInfo[];
        }
        catch (e) {
            return null;
        }
    }
    return null;
}
// ===== 获取数量 =====
export function getCreatorCount(platform: string): number {
    const data = getRawCreatorData(platform);
    return data ? data.length : 0;
}
// ===== 应用跳转偏好 =====
export function isDeepLinkAllowed(): boolean {
    return AppStorage.get<boolean>(STORAGE_KEYS.DEEP_LINK) ?? true;
}
export function setDeepLinkAllowed(allowed: boolean): void {
    AppStorage.setOrCreate(STORAGE_KEYS.DEEP_LINK, allowed);
    // 同时持久化
    setBool(STORAGE_KEYS.DEEP_LINK, allowed);
}
