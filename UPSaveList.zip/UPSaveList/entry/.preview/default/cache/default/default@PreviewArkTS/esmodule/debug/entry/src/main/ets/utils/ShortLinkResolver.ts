import http from "@ohos:net.http";
import { resolveB23Url, resolveVdouyinUrl, extractBilibiliUid, extractDouyinSecUid, extractKuaishouUserId, httpGet } from "@normalized:N&&&entry/src/main/ets/utils/AvatarFetcher&";
import { getSchemeLink } from "@normalized:N&&&entry/src/main/ets/utils/SchemeLinkBuilder&";
// ===== 统一解析结果 =====
export interface ResolvedLink {
    realUrl: string; // 解析后的真实 HTTPS 地址
    uid: string; // 平台用户标识（UID / sec_uid / user_id）
    platform: string; // bilibili / douyin / kuaishou
    deepLink: string; // 可直接 startAbility 的 scheme 深链
}
// ===== 快手短链解析（kuaishou.cn/x/xxx → 真实 profile 地址） =====
async function resolveKuaishouShortUrl(shortUrl: string): Promise<string | null> {
    const httpRequest = http.createHttp();
    try {
        const response = await httpRequest.request(shortUrl, {
            method: http.RequestMethod.GET,
            maxRedirects: 0,
            header: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            connectTimeout: 10000,
            readTimeout: 10000
        });
        if (response.responseCode >= 300 && response.responseCode < 400) {
            const headers = response.header as Record<string, Object>;
            const location: string | undefined = typeof headers['Location'] === 'string' ? headers['Location'] as string :
                typeof headers['location'] === 'string' ? headers['location'] as string :
                    undefined;
            if (location) {
                return location;
            }
        }
        // 兜底：跟随重定向解析 HTML
        const html = await httpGet(shortUrl);
        if (html) {
            const uid = extractKuaishouUserId(html);
            if (uid)
                return uid;
            // 从 og:url 提取
            const ogUrl = html.match(/<meta\s+property="og:url"\s+content="([^"]+)"/);
            if (ogUrl && ogUrl[1])
                return ogUrl[1];
        }
        return null;
    }
    catch (e) {
        console.error('[ShortLinkResolver] resolveKuaishouShortUrl error:', JSON.stringify(e));
        return null;
    }
    finally {
        httpRequest.destroy();
    }
}
// ===== 从 URL 提取平台标识 =====
function detectPlatformFromUrl(url: string): string {
    if (url.includes('bilibili.com') || url.includes('b23.tv'))
        return 'bilibili';
    if (url.includes('douyin.com') || url.includes('iesdouyin.com') || url.includes('v.douyin.com'))
        return 'douyin';
    if (url.includes('kuaishou.com') || url.includes('kuaishou.cn'))
        return 'kuaishou';
    return '';
}
// ===== 从 URL 提取 UID（不发起网络请求） =====
function extractUidDirectly(url: string, platform: string): string | null {
    switch (platform) {
        case 'bilibili':
            return extractBilibiliUid(url);
        case 'douyin':
            return extractDouyinSecUid(url);
        case 'kuaishou':
            return extractKuaishouUserId(url);
        default:
            return null;
    }
}
// ===== 解析短链拿到真实地址和 UID =====
async function resolveShortUrl(shortUrl: string, platform: string): Promise<string | null> {
    switch (platform) {
        case 'bilibili':
            return resolveB23Url(shortUrl);
        case 'douyin':
            return resolveVdouyinUrl(shortUrl);
        case 'kuaishou':
            return resolveKuaishouShortUrl(shortUrl);
        default:
            return null;
    }
}
// ===== 构造真实主页 URL（基于 UID） =====
function buildRealUrl(platform: string, uid: string): string {
    switch (platform) {
        case 'bilibili':
            return `https://m.bilibili.com/space/${uid}`;
        case 'douyin':
            return `https://www.douyin.com/user/${uid}`;
        case 'kuaishou':
            return `https://www.kuaishou.com/profile/${uid}`;
        default:
            return '';
    }
}
// ===== 对外统一接口：解析任意平台链接 → ResolvedLink =====
export async function resolveLink(url: string): Promise<ResolvedLink | null> {
    const platform = detectPlatformFromUrl(url);
    if (!platform)
        return null;
    // ----- 抖音：不做解析（假解析），直接返回原始链接 -----
    // 注意：快手需要解析（短链→HTML提取UID），不能早返回
    if (platform === 'douyin') {
        return {
            realUrl: url,
            uid: '',
            platform: platform,
            deepLink: ''
        };
    }
    // 1. 先尝试从 URL 直接提取 UID（无需网络请求）
    let uid = extractUidDirectly(url, platform);
    if (uid) {
        return {
            realUrl: buildRealUrl(platform, uid),
            uid: uid,
            platform: platform,
            deepLink: getSchemeLink(platform, uid)
        };
    }
    // 2. 判断是否为短链（b23.tv / v.douyin.com / kuaishou.cn/x/xxx）
    const isShortLink = url.includes('b23.tv') ||
        url.includes('v.douyin.com') ||
        /kuaishou\.(com|cn)\/[a-zA-Z0-9]/.test(url);
    if (isShortLink) {
        // 短链 → 发起 HTTP 解析
        const resolvedUid = await resolveShortUrl(url, platform);
        if (resolvedUid) {
            return {
                realUrl: buildRealUrl(platform, resolvedUid),
                uid: resolvedUid,
                platform: platform,
                deepLink: getSchemeLink(platform, resolvedUid)
            };
        }
    }
    // 2.5 兜底：对抖音链接，直接下载 HTML 从中提取 sec_uid
    // 处理非短链的 /note/{id} /video/{id} 等页面，以及短链解析失败的情况
    if (!uid && platform === 'douyin') {
        try {
            const html = await httpGet(url);
            if (html) {
                const htmlUid = extractDouyinSecUidFromHtml(html);
                if (htmlUid) {
                    return {
                        realUrl: buildRealUrl(platform, htmlUid),
                        uid: htmlUid,
                        platform: platform,
                        deepLink: getSchemeLink(platform, htmlUid)
                    };
                }
            }
        }
        catch (_) { /* fallback */ }
    }
    // 2.6 兜底：B站视频页链接（/video/BVxxx → 调 API 拿 owner.mid）
    if (!uid && platform === 'bilibili') {
        try {
            // 方式 A：从 URL 直接提取 BVID → 调 B站 API
            const bvidMatch = url.match(/\/video\/(BV[A-Za-z0-9]+)/);
            if (bvidMatch && bvidMatch[1]) {
                const apiResult = await httpGet(`https://api.bilibili.com/x/web-interface/view?bvid=${bvidMatch[1]}`);
                if (apiResult) {
                    try {
                        const json = JSON.parse(apiResult) as Record<string, Object>;
                        const data = json['data'] as Record<string, Object> | undefined;
                        const owner = data?.['owner'] as Record<string, Object> | undefined;
                        const ownerMid = owner?.['mid'];
                        if (ownerMid !== undefined && ownerMid !== null) {
                            const resolvedUid = String(ownerMid);
                            return {
                                realUrl: buildRealUrl(platform, resolvedUid),
                                uid: resolvedUid,
                                platform: platform,
                                deepLink: getSchemeLink(platform, resolvedUid)
                            };
                        }
                    }
                    catch (_) { /* fallback to HTML */ }
                }
            }
            // 方式 B：下载 HTML 从中搜索 mid / space 链接
            const html = await httpGet(url);
            if (html) {
                // 搜索 "mid":数字
                const midMatch = html.match(/\"mid\"\s*:\s*(\d{5,})/);
                if (midMatch && midMatch[1]) {
                    const resolvedUid = midMatch[1];
                    return {
                        realUrl: buildRealUrl(platform, resolvedUid),
                        uid: resolvedUid,
                        platform: platform,
                        deepLink: getSchemeLink(platform, resolvedUid)
                    };
                }
                // 搜索 space.bilibili.com/{uid}
                const spaceMatch = html.match(/space\.bilibili\.com\/(\d+)/);
                if (spaceMatch && spaceMatch[1]) {
                    const resolvedUid = spaceMatch[1];
                    return {
                        realUrl: buildRealUrl(platform, resolvedUid),
                        uid: resolvedUid,
                        platform: platform,
                        deepLink: getSchemeLink(platform, resolvedUid)
                    };
                }
            }
        }
        catch (_) { /* fallback */ }
    }
    // 2.7 兜底：快手非短链页面（/short-video/xxx 等 → 下载 HTML 提取 user_id）
    if (!uid && platform === 'kuaishou') {
        try {
            const html = await httpGet(url);
            if (html) {
                // 搜索 /profile/{user_id} 路径
                const profileMatch = html.match(/kuaishou\.com\/profile\/([^\/\?#\"\'\s<>]+)/);
                if (profileMatch && profileMatch[1]) {
                    const resolvedUid = profileMatch[1];
                    return {
                        realUrl: buildRealUrl(platform, resolvedUid),
                        uid: resolvedUid,
                        platform: platform,
                        deepLink: getSchemeLink(platform, resolvedUid)
                    };
                }
                // 搜索 "userId":"xxx" 或 "user_id":"xxx"
                const userIdJson = html.match(/\"(?:userId|user_id)\"\s*:\s*\"?(\d+)\"?/);
                if (userIdJson && userIdJson[1]) {
                    const resolvedUid = userIdJson[1];
                    return {
                        realUrl: buildRealUrl(platform, resolvedUid),
                        uid: resolvedUid,
                        platform: platform,
                        deepLink: getSchemeLink(platform, resolvedUid)
                    };
                }
            }
        }
        catch (_) { /* fallback */ }
    }
    // 3. 无法解析，返回 null
    return null;
}
// ===== HTML 内提取抖音 sec_uid（多策略，供本文件兜底使用） =====
function extractDouyinSecUidFromHtml(html: string): string | null {
    // 策略1：douyin.com/user/{sec_uid} 完整 URL
    const urlMatch = html.match(/douyin\.com\/user\/([^\/\?#\"\'\s<>]+)/);
    if (urlMatch && urlMatch[1])
        return urlMatch[1];
    // 策略2：JSON 中 "sec_uid":"xxx"
    const jsonMatch = html.match(/\"sec_uid\"\s*:\s*\"([^\"]+)\"/);
    if (jsonMatch && jsonMatch[1])
        return jsonMatch[1];
    // 策略3：__INITIAL_STATE__ 全局 JSON 中的 sec_uid
    const initState = html.match(/window\.__INITIAL_STATE__\s*=\s*({[^;]+})/);
    if (initState && initState[1]) {
        try {
            const parsed = JSON.parse(initState[1]) as Record<string, Object>;
            const user = parsed['user'] as Record<string, Object> | undefined;
            if (user && user['sec_uid'])
                return String(user['sec_uid']);
            const profile = parsed['profile'] as Record<string, Object> | undefined;
            if (profile && profile['secUid'])
                return String(profile['secUid']);
        }
        catch (_) { /* ignore parse error */ }
    }
    // 策略4：og:url / canonical 中的 /user/{sec_uid}
    const ogUrl = html.match(/<meta\s+property=\"og:url\"\s+content=\"([^\"]+)\"/);
    const canonical = html.match(/<link\s+rel=\"canonical\"\s+href=\"([^\"]+)\"/);
    const linkUrl = ogUrl?.[1] || canonical?.[1];
    if (linkUrl) {
        const uid = linkUrl.match(/douyin\.com\/user\/([^\/\?#]+)/);
        if (uid && uid[1])
            return uid[1];
    }
    // 策略5：任意 /user/{sec_uid} 路径
    const attrMatch = html.match(/\/user\/([a-zA-Z0-9_\-]{10,})/);
    if (attrMatch && attrMatch[1])
        return attrMatch[1];
    return null;
}
