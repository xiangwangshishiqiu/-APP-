if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WebBridgePage_Params {
    controller?: webview.WebviewController;
    pageUrl?: string;
    isLoading?: boolean;
}
import router from "@ohos:router";
import webview from "@ohos:web.webview";
import type common from "@ohos:app.ability.common";
import type Want from "@ohos:app.ability.Want";
const TAG: string = '[WebBridgePage]';
class WebBridgePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = new webview.WebviewController();
        this.__pageUrl = new ObservedPropertySimplePU('', this, "pageUrl");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WebBridgePage_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.pageUrl !== undefined) {
            this.pageUrl = params.pageUrl;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params: WebBridgePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pageUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pageUrl.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: webview.WebviewController;
    private __pageUrl: ObservedPropertySimplePU<string>;
    get pageUrl() {
        return this.__pageUrl.get();
    }
    set pageUrl(newValue: string) {
        this.__pageUrl.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    aboutToAppear(): void {
        const params = router.getParams() as Record<string, Object>;
        const uid: string = (params?.['uid'] as string) || '';
        if (uid) {
            this.pageUrl = `https://m.bilibili.com/space/${uid}`;
            console.info(TAG, '加载 B站页面:', this.pageUrl);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/WebBridgePage.ets(29:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.pageUrl.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/WebBridgePage.ets(31:9)", "entry");
                        Stack.width('100%');
                        Stack.height('100%');
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // Web 组件 — 加载 B站移动端页面
                        Web.create({ src: this.pageUrl, controller: this.controller });
                        Web.debugLine("entry/src/main/ets/pages/WebBridgePage.ets(33:11)", "entry");
                        // Web 组件 — 加载 B站移动端页面
                        Web.width('100%');
                        // Web 组件 — 加载 B站移动端页面
                        Web.height('100%');
                        // Web 组件 — 加载 B站移动端页面
                        Web.backgroundColor('#ffffff');
                        // Web 组件 — 加载 B站移动端页面
                        Web.onLoadIntercept((event) => {
                            const url: string = event?.data?.getRequestUrl() || '';
                            // 拦截 bilibili:// 或 intent:// 深链
                            if (url.startsWith('bilibili://') || url.startsWith('intent://')) {
                                console.info(TAG, '拦截到深链:', url);
                                const ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
                                const want: Want = {
                                    action: 'ohos.want.action.viewData',
                                    entities: ['entity.system.browsable'],
                                    uri: url
                                };
                                ctx.startAbility(want).then(() => {
                                    console.info(TAG, '拉起 B站 App 成功');
                                    router.back();
                                }).catch((e: Error) => {
                                    console.warn(TAG, '拉起 B站 App 失败:', JSON.stringify(e));
                                });
                                return true; // 阻止 Web 组件加载此 URL
                            }
                            return false;
                        });
                        // Web 组件 — 加载 B站移动端页面
                        Web.onPageBegin(() => {
                            this.isLoading = true;
                        });
                        // Web 组件 — 加载 B站移动端页面
                        Web.onPageEnd(() => {
                            this.isLoading = false;
                        });
                    }, Web);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 加载指示器（页面加载完成后自动隐藏）
                        if (this.isLoading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/WebBridgePage.ets(67:13)", "entry");
                                    LoadingProgress.width(48);
                                    LoadingProgress.height(48);
                                    LoadingProgress.color('#fb7299');
                                }, LoadingProgress);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Stack.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('参数错误，无法加载页面');
                        Text.debugLine("entry/src/main/ets/pages/WebBridgePage.ets(76:9)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#999');
                        Text.textAlign(TextAlign.Center);
                        Text.width('100%');
                        Text.height('100%');
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "WebBridgePage";
    }
}
registerNamedRoute(() => new WebBridgePage(undefined, {}), "", { bundleName: "com.example.upsavelist", moduleName: "entry", pagePath: "pages/WebBridgePage", pageFullPath: "entry/src/main/ets/pages/WebBridgePage", integratedHsp: "false", moduleType: "followWithHap" });
