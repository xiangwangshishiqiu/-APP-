if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AvatarComponent_Params {
    avatarUrl?: string;
    name?: string;
    color?: string;
    avatarSize?: number;
    imageFailed?: boolean;
}
export class AvatarComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.avatarUrl = undefined;
        this.name = '';
        this.color = '#FB7299';
        this.avatarSize = 48;
        this.__imageFailed = new ObservedPropertySimplePU(false, this, "imageFailed");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AvatarComponent_Params) {
        if (params.avatarUrl !== undefined) {
            this.avatarUrl = params.avatarUrl;
        }
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.color !== undefined) {
            this.color = params.color;
        }
        if (params.avatarSize !== undefined) {
            this.avatarSize = params.avatarSize;
        }
        if (params.imageFailed !== undefined) {
            this.imageFailed = params.imageFailed;
        }
    }
    updateStateVars(params: AvatarComponent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__imageFailed.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__imageFailed.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private avatarUrl?: string;
    private name: string;
    private color: string;
    private avatarSize: number;
    private __imageFailed: ObservedPropertySimplePU<boolean>;
    get imageFailed() {
        return this.__imageFailed.get();
    }
    set imageFailed(newValue: boolean) {
        this.__imageFailed.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/components/AvatarComponent.ets(14:5)", "entry");
            Stack.width(this.avatarSize);
            Stack.height(this.avatarSize);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.avatarUrl && !this.imageFailed) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 真实头像：圆形裁剪渲染
                        Image.create(this.avatarUrl);
                        Image.debugLine("entry/src/main/ets/components/AvatarComponent.ets(17:9)", "entry");
                        // 真实头像：圆形裁剪渲染
                        Image.width(this.avatarSize);
                        // 真实头像：圆形裁剪渲染
                        Image.height(this.avatarSize);
                        // 真实头像：圆形裁剪渲染
                        Image.borderRadius(this.avatarSize / 2);
                        // 真实头像：圆形裁剪渲染
                        Image.objectFit(ImageFit.Cover);
                        // 真实头像：圆形裁剪渲染
                        Image.onError(() => {
                            // 网络加载失败 → 降级到文字占位
                            this.imageFailed = true;
                        });
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 降级方案：文字首字母 + 彩色圆形背景
                        Circle.create();
                        Circle.debugLine("entry/src/main/ets/components/AvatarComponent.ets(28:9)", "entry");
                        // 降级方案：文字首字母 + 彩色圆形背景
                        Circle.width(this.avatarSize);
                        // 降级方案：文字首字母 + 彩色圆形背景
                        Circle.height(this.avatarSize);
                        // 降级方案：文字首字母 + 彩色圆形背景
                        Circle.fill(this.color);
                    }, Circle);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.name.charAt(0));
                        Text.debugLine("entry/src/main/ets/components/AvatarComponent.ets(32:9)", "entry");
                        Text.fontSize(this.avatarSize * 0.42);
                        Text.fontColor(Color.White);
                        Text.fontWeight(FontWeight.Bold);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
